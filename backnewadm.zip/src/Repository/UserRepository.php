<?php
namespace App\Repository;

use Doctrine\DBAL\Portability\Connection;
use Doctrine\ORM\EntityRepository;
use App\Services\HTTPRequestSender;
use Doctrine\ORM\NoResultException;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Cache\Adapter\RedisAdapter;
use Symfony\Component\HttpFoundation\Session\Session;
use App\Utils\Configuration;


class UserRepository extends EntityRepository
{

    function getUserSessionInfo($usr){
        $sql = "SELECT aus_id, aus_name, aus_access, aty_code, aus_jurisdiction_id, aus_cou_id, aus_password, aus_username" . "  , aus_failed_logins, aus_lock_start" . "  , aus_password_set_time" . "  , aty_jurisdiction_class, jur_code, aus_ssl_key, aus_has_key, aus_aty_id, aty_level, jur_available_credit,jur_overdraft,jur_reserved_fund, jur_skn_id, jur_childs_limit, jur_users_limit " . "  , cur_name,cur_code_for_web,cur_id " . "  FROM admin_user
                       LEFT JOIN admin_user_type ON aty_id = aus_aty_id
                       LEFT JOIN jurisdiction on jur_id = aus_jurisdiction_id
                       LEFT JOIN currency on cur_id = jur_currency " . " WHERE aus_username = '$usr'" ;
        $em = $this->getEntityManager();
        $em->getConnection()->setAutoCommit(true);
        $connection = $em->getConnection();

        try {
            $statement = $connection->prepare($sql);
            $statement->execute();
        } catch (\Doctrine\DBAL\Exception $e) {
            return $e->getCode().' with error :'.$e->getMessage();
        }

        try{
            $result = $statement->fetchAllAssociative();
            return $result;
        } catch (\Doctrine\DBAL\Driver\Exception $e) {
            return $e->getCode().' with error :'.$e->getMessage();
        }
    }

    function getAllClubsUnderJurisdiction($jur_id,$recent=false) {

        $jur_class=$_SESSION['jurisdiction_class'];
        $sql = "select c.jur_name club_name,c.jur_id club_id,d.jur_name district_name
            FROM jurisdiction c
            JOIN jurisdiction d on d.jur_id = c.jur_parent_id";
        if($jur_class == "club"){
            $sql .= " WHERE c.jur_id = " . $jur_id;
        }
        elseif($jur_class == "district"){
            $sql .= "
				  WHERE d.jur_id = " . $jur_id;
        }
        elseif($jur_class=="region"){        $sql .="
				  JOIN jurisdiction r on r.jur_id = d.jur_parent_id
				  WHERE r.jur_id=".$jur_id;
        }
        elseif ($jur_class=="nation"){
            $sql .=" JOIN jurisdiction r on r.jur_id = d.jur_parent_id
				 JOIN jurisdiction n on n.jur_id = r.jur_parent_id
				WHERE n.jur_id=".$jur_id;
        }
        else{
            $sql .=" WHERE 1=1";
        }
        $sql.=" AND c.jur_class='club'
            AND c.jur_status=1";
        if($recent){
            $sql.=" AND c.JUR_CREATION_DATE > now() - interval 120 day";
        }

        $em = $this->getEntityManager();
        $em->getConnection()->setAutoCommit(true);
        $connection = $em->getConnection();

        try {
            $statement = $connection->prepare($sql);
            $statement->execute();
        } catch (\Doctrine\DBAL\Exception $e) {
            return $e->getCode().' with error :'.$e->getMessage();
        }

        try{
            $result = $statement->fetchAllAssociative();
            return $result;
        }catch (\Doctrine\ORM\NoResultException $e)
        {
            return $e->getCode().' with error :'.$e->getMessage();
        }
    }

    function getUsersSearch($jurId,$max_row,$exact,$field,$orderby,$operation,$asc_desc){
        $sql       = "";
        if ($_SESSION["jurisdiction_class"] == "club") {
            $jurisdiction_level = "club";
            $jurisdiction       = $jurId;
        }

        $safe_checked = 1;
        if (empty($search_string) &&
            ($_SESSION["jurisdiction_class"] == "club" || $jurisdiction_level == "club")) {
            $search_type = SEARCH_TYPE_EMPTY;
        } elseif($field == 0) {
            if (preg_match(RGX_NUMER, $search_string)) {
                $search_type =  SEARCH_TYPE_CUSTNUM;
                settype($search_string, 'integer');
            }
            elseif (preg_match(RGX_EMAIL, $search_string)) {
                $search_type = SEARCH_TYPE_EMAIL;
                $safe_str    = strtolower(str_replace('%', '%%', $search_string));
            }
            elseif (preg_match(RGX_IPADD, $search_string)) {
                $search_type = SEARCH_TYPE_IPADDRESS;
            }elseif (preg_match(RGX_NIN_CODE, $search_string)){
                $search_type = SEARCH_TYPE_NIN_CODE;
            }elseif (preg_match(RGX_NAME, $search_string)){
                $search_type = SEARCH_TYPE_NAME;
            }
            else {
                $search_type = SEARCH_TYPE_USERNAME;
                $safe_str    = $search_string; //Modificata Manuel Rinaldi

            }
        }
        elseif ($field == 1) {
            $search_type = SEARCH_TYPE_USERNAME;
            $safe_str    = $search_string; //Modificata Manuel Rinaldi

        }
        elseif ($field == 2) {
            $search_type = SEARCH_TYPE_CUSTNUM ;
            $search_string= (int)$search_string;

        }
        elseif ($field == 3) {
            $search_type = SEARCH_TYPE_EMAIL;
            $safe_str    = strtolower(str_replace('%', '%%', $search_string));
        }
        elseif ($field == 4) {
            $search_type = SEARCH_TYPE_IPADDRESS;
        }
        elseif ($field == 5){
            $search_type = SEARCH_TYPE_NIN_CODE;
        }
        elseif ($field == 6){
            $search_type = SEARCH_TYPE_NAME;
        }

        elseif ($field == 7){
            $search_type = SEARCH_TYPE_PARTNERUSER;
            $search_string = (int)$search_string;


        }

        $sql  = "select pun_id, pun_first_name, pun_middle_name, pun_last_name" .
            ", pun_member_type, pcr_credits, pun_access, pcr_total_bets" .
            ", pcr_total_wins, pun_email, pun_username, pun_reg_date" .
            ", pun_customer_number, pun_identified" .
            ", pun_notes, cou_name, pun_investigate" .
            ", pun_dob, pun_address_line1, pun_address_line2, pun_city_suburb" .
            ", pun_state_province, pun_postcode_zip, pun_phone_business" .
            ", pun_phone_home, pun_phone_mobile, pun_fax, pun_daily_allowance" .
            ", pun_gender, pun_temp_password, pun_num_logins, pun_last_logged_in" .
            ", pcr_reserved_funds, pun_lock_reason, pun_id_documents, pun_preg_code" .
            ", pun_login_lock_start, pun_email_reg_code, pun_sms_reg_code" .
            ", pun_registration_status, pun_pre_registered, pcr_total_deposits,pcr_fees_retained" .
            ", pcr_total_withdrawals, pun_password_set_time, pun_sre_code, pun_confirmation_list" .
            ", c.jur_name as \"Betting Club\"".
            ", d.jur_name as \"District\"".
            ", r.jur_name as \"Region\"".
            ", n.jur_name as \"Nation\"".
            ", cur_code_for_web as pun_currency ".
            " FROM punter " .
            " LEFT JOIN punter_credit on pun_id=pcr_pun_id " .
            " LEFT JOIN jurisdiction c ON pun_betting_club=c.jur_id" .
            " LEFT JOIN jurisdiction d ON c.jur_parent_id=d.jur_id" .
            " LEFT JOIN jurisdiction r ON d.jur_parent_id=r.jur_id" .
            " LEFT JOIN jurisdiction n ON r.jur_parent_id=n.jur_id" .
            " LEFT JOIN currency ON c.jur_currency=cur_id " ;
        if($search_type == SEARCH_TYPE_IPADDRESS ){
            $sql .=" JOIN customer_log  ON clg_punid=pun_id";
        }
        $sql .=" LEFT OUTER JOIN country ON pun_cou_code = cou_code" .
            " WHERE pcr_pun_id = pun_id "; //Modificata query Manuel Rinaldi

        if (isset($safe_checked) && !empty($jurisdiction_level) && !empty($jurisdiction)) {
            if ($jurisdiction_level == "club"){
                $sql .= " AND c.jur_id =".$jurisdiction;
            }
            elseif ($jurisdiction_level == "district"){
                $sql .= " AND d.jur_id =".$jurisdiction;
            }
            elseif ($jurisdiction_level == "region"){
                $sql .= " AND r.jur_id =".$jurisdiction;
            }
            elseif ($jurisdiction_level == "nation"){
                $sql .= " AND n.jur_id =".$jurisdiction;
            }
            else {
                $sql .= " AND 1 = 0 ";
            }
        }
        else {
            if ( 'club' == $_SESSION['jurisdiction_class'] ) { //If a club admin user
                //only show punters in same club as admin user
                $sql .= " and c.jur_id = ".$_SESSION['jurisdiction_id'];
            }
            elseif ( 'district' == $_SESSION['jurisdiction_class'] )  { //If a district manager admin user
                $sql .= " and d.jur_id = ".$_SESSION['jurisdiction_id'];
            }
            elseif ( 'region' == $_SESSION['jurisdiction_class'] ) { //If a district manager admin user
                // only select punters where their betting club (bottom level jurisdiction)
                // is under the admin user's district
                // select only  records within admin user's jurisdiction
                $sql .= " and r.jur_id = ".$_SESSION['jurisdiction_id'];
            }
            elseif ( 'nation' == $_SESSION['jurisdiction_class'] )  { //If a district manager admin user
                // only select punters where their betting club (bottom level jurisdiction)
                // is under the admin user's district
                // select only  records within admin user's jurisdiction
                $sql .= " and n.jur_id = ".$_SESSION['jurisdiction_id'];
            }
            elseif ( 'casino' != $_SESSION["jurisdiction_class"] ) {
                $sql .= " and 1 = 0 ";
            }
        }

        if ($search_type == SEARCH_TYPE_USERNAME) {
            if ($exact)
                $sql .= " AND pun_username=".($search_string);
            else
                $sql .= " AND pun_username LIKE '%$safe_str%'"; //Modificata query Manuel Rinaldi
        }
        elseif ($search_type == SEARCH_TYPE_EMAIL) {
            if ($exact)
                $sql .= " AND pun_email=" . ($search_string);
            else
                $sql .= " AND pun_email LIKE ('%$safe_str%')";
        }
        elseif ($search_type == SEARCH_TYPE_PARTNERUSER) {

            $sql .= " AND (";
            $sql .= " pun_id IN (SELECT pnu_local_id FROM partner_users WHERE pnu_id = $search_string) ";
            $sql .= ")";
        }
        elseif ($search_type == SEARCH_TYPE_CUSTNUM) {
            $sql .= " AND (";
            $sql .= " (pun_customer_number = $search_string OR pun_id = $search_string ) ";

            /* if($_SERVER["HTTP_HOST"] == "poker.leonardogames.it"){
             $sql .= " OR REGEXP_LIKE(pun_first_name, '[a-z0-9]{3}_$search_string', 'i')";
            $sql .= " OR pun_id IN (SELECT pnu_local_id FROM partner_users WHERE pnu_username = 'itp_$search_string')";
            }*/ //Modificata query Manuel Rinaldi

            $sql .= ")";


            //$sql .= " AND (pun_customer_number = $search_string OR pun_id = $search_string OR REGEXP_LIKE(pun_first_name, '[a-z0-9]{3}_$search_string', 'i') OR pun_id IN (SELECT pnu_local_id FROM partner_users WHERE pnu_id = $search_string))";
        }

        elseif ($search_type == SEARCH_TYPE_IPADDRESS) {
            $sql .= " AND pun_id  = clg_punid AND clg_ipaddress = " . ($search_string) ." GROUP BY pun_id ";
            $ip =$search_string;
//                    require_once 'getIp.php';
        }
        elseif ($search_type == SEARCH_TYPE_NIN_CODE){
            $sql .= " AND pun_nin_code = " . ($search_string) . " ";
        }elseif ($search_type == SEARCH_TYPE_NAME) {
            list($last_name, $first_name) = explode(",", $search_string);

            $sql .= " AND (TRIM(pun_last_name) = " . (trim(strtolower($last_name )));

            if(!is_null($first_name)){
                $sql .= " AND TRIM(pun_first_name) = " . (trim(strtolower($first_name)));
            }
            $sql .= ")";
        }
        elseif ($search_type != SEARCH_TYPE_EMPTY) {
            $sql .= " AND 1 = 0 ";

        }

//            $orderby   = $orderby;
//            $operation = $operation;
//            $asc_desc  = $asc_desc;

        if($max_row == NULL)
            $max_row = 20;


        if ( 'desc' == $asc_desc || !$orderby )
            $asc_desc = 'desc';
        else
            $asc_desc = 'asc';

        switch ($orderby )
        {  case "number":
            $sql .= " order by pun_customer_number";
            $sql .= ", upper(pun_middle_name)";
            break;
            case "country":
                $sql .= " order by upper(cou_name)";
                break;
            case "member_type":
                $sql .= " order by upper(pun_member_type)";
                break;
            case "status":
                $sql .= " order by lower(pun_registration_status), lower(pun_access) ";
                break;
            case "city":
                $sql .= " order by lower(pun_city_suburb)";
                break;
            case "funds":
                $sql .= " order by pcr_credits";
                break;
            case "bets":
                $sql .= " order by pcr_total_bets";
                break;
            case "wins":
                $sql .= " order by pcr_total_wins";
                break;
            case "access":
                $sql .= " order by pun_access";
                break;
            case "email":
                $sql .= " order by lower(pun_email)";
                break;
            case "investigate":
                $sql .= " order by lower(pun_investigate  )";
                break;
            case "num_logins":
                $sql .= " order by lower(pun_num_logins)";
                break;
            case "last_login":
                $sql .= " order by pun_last_logged_in";
                break;
            case "deposits":
                $sql .= " order by pcr_total_deposits";
                break;
            case "withdrawals":
                $sql .= " order by pcr_total_withdrawals";
                break;
            case "name":
                $sql .= " order by upper(pun_last_name) $asc_desc, upper(pun_first_name)";
                $sql .= ", upper(pun_middle_name)";
                break;
            case "fees":
                $sql .= " order by pcr_fees_retained";
                break;
            case "returned":
                $sql .= " order by pcr_total_bets-pcr_total_wins";
                break;

            case "Betting Club":
                $sql .= " order by \"Betting Club\"";
                break;
            case "District":
                $sql .= " order by \"District\"";
                break;
            case "Region":
                $sql .= " order by \"Region\"";
                break;
            case "Nation":
                $sql .= " order by \"Nation\"";
                break;
            //order by name
            default:{
                $orderby = 'reg_date';
                $sql .= " order by pun_reg_date";
            }
        }




        $sql .= " $asc_desc"; //ascending or descending
//echo $sql;
//die($sql);

        $em = $this->getEntityManager();
        $em->getConnection()->setAutoCommit(true);
        $connection = $em->getConnection();

        try {
            $statement = $connection->prepare($sql);
            $statement->execute();
        } catch (\Doctrine\DBAL\Exception $e) {
            return $e->getCode().' with error :'.$e->getMessage();
        }
        try{
            $rs = $statement->fetchAllAssociative();
//            return $result;

//$rs  =  $dbh->getResults();//execute search query
            $num_rows = $rs->getNumRows();

            if ( $num_rows  > 0 ){
                $num_rows_displayed = 0;
                $delete_image = '<img src="'.image_dir.'/button_delete.gif" border=0>';  //delete button
                //begin formatting rows
                $i=0;

                while ( $row = $rs->next() ){
//   	var_dump($row);  
                    // if a transient customer
                    if ( empty($row['pun_first_name']) && empty($row['pun_middle_name']) && empty($row['pun_last_name']))
                        $name_disp = $row['pun_username'];
                    else
                        $name_disp = $row['pun_username'] . "<br/><font color='Gray'>" . $row['pun_last_name'] . ', ' . $row['pun_first_name']. ' ' . $row['pun_middle_name'] . "</font>";

                    $display[$i]['Customer'] .= '<table cellpadding=0 cellspacing=0 border=0><tr valign=top><td class=small colspan=2>';
                    //"Customer" column
                    $display[$i]['Customer'] .= getLink(refPage('customers/customer_view&customer_id='.$row['pun_id']), $name_disp, 'contentlink');
                    $display[$i]['Customer'] .= '<br>'.$row['pun_email'];
                    if ( $this->inConfirmationList('email', $row['pun_confirmation_list']) )
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_activated_sm.gif">';
                    $display[$i]['Customer'] .= '</td></tr><tr><td class=small>'.$row['pun_customer_number'].'</td><td>';

                    if ( 'FINANCIAL' == $row['pun_member_type'] )
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_financial.gif" alt="Financial">';
                    else
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_nonfinancial.gif" alt="Nonfinancial">';

                    if ( -1 == $row['pun_identified'] )
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_transient.gif" alt="Transient customer">';

                    if ( 'deny' == $row['pun_access'] )
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_lock.gif" alt="Account Locked">';

                    if ( $row['pun_investigate'] )
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_investigate.gif" alt="Account Investigate">';

                    if ( $row['pun_pre_registered'] )
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_preg.gif" alt="Pregistration">';

                    switch ( $row['pun_registration_status'] )
                    {  case 'pending':
                        $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_waiting.gif" alt="Activation Pending">';
                        break;
                        case 'activated':
                            $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_activated.gif" alt="Account activated">';
                            break;
                        case 'email bounced':
                            $display[$i]['Customer'] .= '<img src="'.image_dir.'/icon_email_fail.gif" alt="Email send failed">';
                            break;
                        default:
                            $display[$i]['Customer'] .=  $row['pun_member_type'];
                    }

                    $display[$i]['Customer'] .= '</td></tr></table>';

                    $x = floor($i / $max_row);

                    $start_row = $x*$max_row+1;


                    $getstr = "doQuery=yes&operation=delete&customer_id=".$row['pun_id']."&start_row=$start_row&num_rows=$num_rows&num_rows_displayed=$num_rows_displayed&max_rows=$max_row&$filter";

                    if ( ! $row['pun_num_logins'] && $row['pcr_total_deposits'] == 0 && hasCustomerDeletePriv($_SESSION['aty_code']) )
                        $display[$i]['Customer'] .= "<br><br><A HREF=\"javascript:doDelete('$getstr','" . replace_quotes($dbh->escapeQuotesAndSlashes(trim($name_disp))) . "')\">".$delete_image.'</A>';


                    //"Location" Column
                    $display[$i]['Location'] = $row['pun_city_suburb'].'<br>'.$row['cou_name'];
                    if ( $row['pun_phone_mobile'] )
                    {  $display[$i]['Location'] .= '<br>'.$row['pun_phone_mobile'];
                        if ( $this->inConfirmationList('mobile', $row['pun_confirmation_list']) )
                            $display[$i]['Location'] .= '<img src="'.image_dir.'/icon_activated_sm.gif">';
                    }
                    //"Login" Column
                    $last_login = dbTsToPhpTs($row['pun_last_logged_in']);
                    $reg_date = dbTsToPhpTs($row['pun_reg_date']);

                    if ( $last_login < $reg_date ) // (defaults to epoch on customer record insert)
                        $last_login = '(Never logged in)';
                    else
                        $last_login = shortDate($row['pun_last_logged_in'],true);

                    $display[$i]['Login']  = shortDate($row['pun_reg_date'],true).'<br>'.$last_login;
                    $display[$i]['Login'] .= '<br>'.( $row['pun_num_logins'] ? $row['pun_num_logins'] : 0 );

                    $func = ( 'FINANCIAL' == $row['pun_member_type'] ? 'getInDollars' : 'getInFunTokens');

                    //Account Balance Column
                    $display[$i]['Balance'] .= $func($row['pcr_credits'],2,$row['pun_currency']);

                    //Transactions Column
                    $display[$i]['Transactions'] .= $func($row['pcr_total_deposits']);
                    $display[$i]['Transactions'] .= '<br>'.$func($row['pcr_fees_retained']);
                    $display[$i]['Transactions'] .= '<br>'.$func($row['pcr_total_withdrawals']);

                    //Bets Column
                    $display[$i]['Bets'] .= $func($row['pcr_total_bets']);
                    $display[$i]['Bets'] .= '<br>'.$func($row['pcr_total_wins']);
                    $display[$i]['Bets'] .= '<br>'.$func($row['pcr_total_bets']-$row['pcr_total_wins']);

                    //Jurisdiction Columns
                    /*echo "<pre>";
                    var_dump($row);
                    echo "</pre>";*/
                    $display[$i]['Betting Club'] = $row['betting club'];
                    $display[$i]['District'] = $row['district'];
                    $display[$i]['Region'] = $row['region'];
                    $display[$i]['Nation'] = $row['nation'];
                    $i++;
                }
                //var_dump($display);
                //die();
                $rs = new RecordSet($display);
                $num_rows =$rs->getNumRows();

                //if ( 1 == $num_rows ){
                //header("Location: ".refPage('customers/customer_view&customer_id='.$row['pun_id']));
                //exit;
                //}
//                $rs->serialize($serialize_filename);

                if ( ! $start_row || ($start_row > $max_row))
                    $start_row=1;

                $show_search_results = true;
                return '';
            }else{
                return ("No Matching Customers Found");
            }
        } catch (\Doctrine\DBAL\Driver\Exception $e) {
            return $e->getCode().' with error :'.$e->getMessage();
        }

    }

    function inConfirmationList($medium, $confirmation_str) {
        if ( $confirmation_str ){
            $arr = explode(',', strtolower($confirmation_str));
            return in_array(strtolower($medium), $arr);
        }
        return false;
    }
}