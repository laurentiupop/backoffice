<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/users/search.html.twig */
class __TwigTemplate_34e3b2f6a683c1c1911fabeccfcca1f7afa354ec7a84a0661a0fed83771abd81 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/users/search.html.twig"));

        // line 1
        echo "<article class=\"col-sm-12 col-md-12 col-lg-12\">
    <!-- new widget -->
    <div class=\"jarviswidget jarviswidget-color-blueDark\" id=\"wid-id-1\" data-widget-editbutton=\"false\" data-widget-fullscreenbutton=\"false\">

    <style>
        div .label{
            color:#333!important;
        }
        div, td{
            text-align: left;
        }
    </style>

        <header>
            <span class=\"widget-icon\"> <i class=\"fa fa-comments txt-color-white\"></i> </span>
            <h2> ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 16, $this->source); })()), "getLang", [0 => "Filtre"], "method", false, false, false, 16), "html", null, true);
        echo " </h2>
            <div class=\"widget-toolbar\">
                <!-- add: non-hidden - to disable auto hide -->


            </div>
        </header>

        <!-- widget div-->
        <div>
            <!-- widget edit box -->
            <div class=\"jarviswidget-editbox\">
                <div>
                    <label>Title:</label>
                    <input type=\"text\" />
                </div>
            </div>
            <!-- end widget edit box -->

            <div class=\"widget-body widget-hide-overflow no-padding\">
                <!-- content goes here -->

                <form id=\"searchUserForm\" method=\"POST\">
                    <table cellpadding=\"4\" cellspacing=\"0\" border=\"0\">
                        ";
        // line 41
        echo "                            ";
        // line 42
        echo "                        ";
        // line 43
        echo "                        ";
        // line 44
        echo "                            ";
        // line 45
        echo "                        ";
        // line 46
        echo "                        <tr valign=top>
                            <td colspan=2 class=formheading><b>";
        // line 47
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 47, $this->source); })()), "getLang", [0 => "Quick Search"], "method", false, false, false, 47), "html", null, true);
        echo "</td>
                        </tr>
                        <tr>
                            <td class=\"label\" >";
        // line 50
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 50, $this->source); })()), "getLang", [0 => "Search type"], "method", false, false, false, 50), "html", null, true);
        echo "</td>
                            <td>
                                <select name=\"field\">
                                    <option value=\"0\">";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 53, $this->source); })()), "getLang", [0 => "Smart"], "method", false, false, false, 53), "html", null, true);
        echo "</option>
                                    <option value=\"1\">";
        // line 54
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 54, $this->source); })()), "getLang", [0 => "User"], "method", false, false, false, 54), "html", null, true);
        echo "</option>
                                    <option value=\"2\">";
        // line 55
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 55, $this->source); })()), "getLang", [0 => "Customer number"], "method", false, false, false, 55), "html", null, true);
        echo "</option>
                                    <option value=\"3\">";
        // line 56
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 56, $this->source); })()), "getLang", [0 => "Mail address"], "method", false, false, false, 56), "html", null, true);
        echo "</option>
                                    <option value=\"4\">";
        // line 57
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 57, $this->source); })()), "getLang", [0 => "IP address"], "method", false, false, false, 57), "html", null, true);
        echo "</option>
                                    <option value=\"6\">";
        // line 58
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 58, $this->source); })()), "getLang", [0 => "Surname, Name"], "method", false, false, false, 58), "html", null, true);
        echo "</option>
                                    <option value=\"7\">";
        // line 59
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 59, $this->source); })()), "getLang", [0 => "Partner user id"], "method", false, false, false, 59), "html", null, true);
        echo "</option>
                                    ";
        // line 61
        echo "                                    ";
        // line 62
        echo "                                    ";
        // line 63
        echo "                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"label\">";
        // line 67
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 67, $this->source); })()), "getLang", [0 => "String Search"], "method", false, false, false, 67), "html", null, true);
        echo ": </td>
                            <td class=\"content\"> <input name=\"search_string\" type=\"text\" value=\"\" /></td>
                        </tr>
                        <tr>
                            <td class=\"label\">";
        // line 71
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 71, $this->source); })()), "getLang", [0 => "Exactly Result"], "method", false, false, false, 71), "html", null, true);
        echo ": </td>
                            <td class=\"content\"> <input type=\"checkbox\" name=\"exact\" ></td>
                        </tr>
                        <tr>
                            <td class=\"label\">";
        // line 75
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 75, $this->source); })()), "getLang", [0 => "Records per page"], "method", false, false, false, 75), "html", null, true);
        echo ": </td>
                            ";
        // line 77
        echo "        ";
        // line 78
        echo "            ";
        // line 79
        echo "                            <td class=\"content\">
                                <select name=\"max_rows\">
                                    <option value=\"10\">10</option>
                                    <option value=\"30\">30</option>
                                    <option value=\"60\">60</option>
                                    <option value=\"100\">100</option>
                                </select>
                            </td>
                        </tr>

                        ";
        // line 90
        echo "                    ";
        // line 91
        echo "                    ";
        // line 92
        echo "                    ";
        // line 93
        echo "
                        ";
        // line 95
        echo "        ";
        // line 96
        echo "        ";
        // line 97
        echo "                        <tr>
                            <td colspan=\"2\">
                                <input type=\"hidden\" name=\"page\" value=\"customers/search\">
                                <input type=\"hidden\" name=\"start_search\" value=\"yes\">
                                <input type=\"hidden\" name=\"doQuery\" value=\"yes\">
                                <input type=\"submit\" value=\"";
        // line 102
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 102, $this->source); })()), "getLang", [0 => "Search"], "method", false, false, false, 102), "html", null, true);
        echo "\">
                            </td>
                        </tr>
                    </table>
                </form>


                <!-- end content -->
            </div>

        </div>
        <!-- end widget div -->
    </div>
    <!-- end widget -->


</article>

<article class=\"col-sm-12 col-md-12 col-lg-12\">
    <!-- new widget -->
    <div class=\"jarviswidget jarviswidget-color-blueDark\" id=\"wid-id-1\" data-widget-editbutton=\"false\" data-widget-fullscreenbutton=\"false\">

    <style>
        div .label{
            color:#333!important;
        }
        div, td{
            text-align: left;
        }
    </style>

        <header>
            <span class=\"widget-icon\"> <i class=\"fa fa-comments txt-color-white\"></i> </span>
            <h2> ";
        // line 135
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 135, $this->source); })()), "getLang", [0 => "Search results"], "method", false, false, false, 135), "html", null, true);
        echo " </h2>
            <div class=\"widget-toolbar\">
                <!-- add: non-hidden - to disable auto hide -->


            </div>
        </header>

        <!-- widget div-->
        <div>
            <!-- widget edit box -->
            <div class=\"jarviswidget-editbox\">
                <div>
                    <label>Title:</label>
                    <input type=\"text\" />
                </div>
            </div>
            <!-- end widget edit box -->

            <div class=\"widget-body widget-hide-overflow no-padding\" id=\"searchResults\">
                <!-- content goes here -->




                <!-- end content -->
            </div>

        </div>
        <!-- end widget div -->
    </div>
    <!-- end widget -->


</article>

<script>
    \$(document).ready(function(){
        // \$.post(\"https://testadm.cspstar.com/services/jurisdiction_services.inc\",{action:\"7\",
        //     jur_id:\$(\"#jurisdictionFast\").val()
        // }, function(data){
        //     \$('#skinFast').text(data);
        // });

        \$('#searchUserForm').on('submit',function (e) {
            e.preventDefault();

            var data = \$(this).serializeArray();
            \$.ajax({
                url: '";
        // line 184
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_search");
        echo "',
                method: \"POST\",
                data: data,


            }).done(function (data) {
                console.log(data)
                if (data == 'expired') {
                    \$.bigBox({
                        title : \"";
        // line 193
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 193, $this->source); })()), "getLang", [0 => "Session expired"], "method", false, false, false, 193), "html", null, true);
        echo "\",
                        content : \"";
        // line 194
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 194, $this->source); })()), "getLang", [0 => "Your session has expired, please login again"], "method", false, false, false, 194), "html", null, true);
        echo "!\",
                        color : \"#C46A69\",
                        //timeout: 6000,
                        icon : \"fa fa-warning shake animated\",
                        number : \"1\",
                        timeout : 6000
                    });
                } else {
                    try {
                        \$.bigBox({
                            title : \"";
        // line 204
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 204, $this->source); })()), "getLang", [0 => "Success"], "method", false, false, false, 204), "html", null, true);
        echo "\",
                            content : \"";
        // line 205
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 205, $this->source); })()), "getLang", [0 => "You registered a user"], "method", false, false, false, 205), "html", null, true);
        echo "!\",
                            color : \"#76BA1B\",
                            //timeout: 6000,
                            icon : \"fa fa-thumbs-up shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        if (data == 0) {
                            \$('#addUserFastModal').modal('hide');

                            \$('#accountFastForm').closest('form').find(\"input[type=text]\").val(\"\");


                            //                                                window.location.href = '/login';
                        }

                        \$('#searchResults').empty().append(data)


                        if (data == -28) {

                        }

                        if (data != 0 && data != -28) {
                        }

                        return data;
                    }
                    catch (e) {
                        console.log(e);
                        \$.bigBox({
                            title : \"";
        // line 236
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 236, $this->source); })()), "getLang", [0 => "Error"], "method", false, false, false, 236), "html", null, true);
        echo "\",
                            content : \"";
        // line 237
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 237, $this->source); })()), "getLang", [0 => "Something went wrong"], "method", false, false, false, 237), "html", null, true);
        echo "!\",
                            color : \"#C46A69\",
                            //timeout: 6000,
                            icon : \"fa fa-warning shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        return false;
                    }
                }
            })
                .fail(function (error) {
                    console.log(error);
                    return false
                })
                .always(function () {
                    return false
                });
            return false;
        })
    })
</script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/users/search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  360 => 237,  356 => 236,  322 => 205,  318 => 204,  305 => 194,  301 => 193,  289 => 184,  237 => 135,  201 => 102,  194 => 97,  192 => 96,  190 => 95,  187 => 93,  185 => 92,  183 => 91,  181 => 90,  169 => 79,  167 => 78,  165 => 77,  161 => 75,  154 => 71,  147 => 67,  141 => 63,  139 => 62,  137 => 61,  133 => 59,  129 => 58,  125 => 57,  121 => 56,  117 => 55,  113 => 54,  109 => 53,  103 => 50,  97 => 47,  94 => 46,  92 => 45,  90 => 44,  88 => 43,  86 => 42,  84 => 41,  57 => 16,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<article class=\"col-sm-12 col-md-12 col-lg-12\">
    <!-- new widget -->
    <div class=\"jarviswidget jarviswidget-color-blueDark\" id=\"wid-id-1\" data-widget-editbutton=\"false\" data-widget-fullscreenbutton=\"false\">

    <style>
        div .label{
            color:#333!important;
        }
        div, td{
            text-align: left;
        }
    </style>

        <header>
            <span class=\"widget-icon\"> <i class=\"fa fa-comments txt-color-white\"></i> </span>
            <h2> {{ translator.getLang('Filtre') }} </h2>
            <div class=\"widget-toolbar\">
                <!-- add: non-hidden - to disable auto hide -->


            </div>
        </header>

        <!-- widget div-->
        <div>
            <!-- widget edit box -->
            <div class=\"jarviswidget-editbox\">
                <div>
                    <label>Title:</label>
                    <input type=\"text\" />
                </div>
            </div>
            <!-- end widget edit box -->

            <div class=\"widget-body widget-hide-overflow no-padding\">
                <!-- content goes here -->

                <form id=\"searchUserForm\" method=\"POST\">
                    <table cellpadding=\"4\" cellspacing=\"0\" border=\"0\">
                        {#<tr>#}
                            {#<th colspan=2 class=\"heading\">{{ translator.getLang('Quick Search') }} &nbsp;&nbsp;|&nbsp;&nbsp;</th>#}
                        {#</tr>#}
                        {#<tr>#}
                            {#<td colspan=2>&nbsp;</td>#}
                        {#</tr>#}
                        <tr valign=top>
                            <td colspan=2 class=formheading><b>{{ translator.getLang('Quick Search') }}</td>
                        </tr>
                        <tr>
                            <td class=\"label\" >{{ translator.getLang('Search type') }}</td>
                            <td>
                                <select name=\"field\">
                                    <option value=\"0\">{{ translator.getLang('Smart') }}</option>
                                    <option value=\"1\">{{ translator.getLang('User') }}</option>
                                    <option value=\"2\">{{ translator.getLang('Customer number') }}</option>
                                    <option value=\"3\">{{ translator.getLang('Mail address') }}</option>
                                    <option value=\"4\">{{ translator.getLang('IP address') }}</option>
                                    <option value=\"6\">{{ translator.getLang('Surname, Name') }}</option>
                                    <option value=\"7\">{{ translator.getLang('Partner user id') }}</option>
                                    {#<?php if(DOT_IT) : ?>#}
                                    {#<option value=\"5\"<?= (\$field == 5) ? ' selected' : '' ?>> <?=\$lang->getLang(\"National Insurance number\")?></option>#}
                                    {#<?php endif; ?>#}
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"label\">{{ translator.getLang('String Search') }}: </td>
                            <td class=\"content\"> <input name=\"search_string\" type=\"text\" value=\"\" /></td>
                        </tr>
                        <tr>
                            <td class=\"label\">{{ translator.getLang('Exactly Result') }}: </td>
                            <td class=\"content\"> <input type=\"checkbox\" name=\"exact\" ></td>
                        </tr>
                        <tr>
                            <td class=\"label\">{{ translator.getLang('Records per page') }}: </td>
                            {#<?php#}
        {#if (\$_SESSION[\"jurisdiction_class\"] != \"club\") {#}
            {#?>#}
                            <td class=\"content\">
                                <select name=\"max_rows\">
                                    <option value=\"10\">10</option>
                                    <option value=\"30\">30</option>
                                    <option value=\"60\">60</option>
                                    <option value=\"100\">100</option>
                                </select>
                            </td>
                        </tr>

                        {#<?php#}
                    {#include('jurisdiction_filters.php');#}
                    {#include('jurisdiction_filter_tabrow.php');#}
                    {#?>#}

                        {#<?php#}
        {#}#}
        {#?>#}
                        <tr>
                            <td colspan=\"2\">
                                <input type=\"hidden\" name=\"page\" value=\"customers/search\">
                                <input type=\"hidden\" name=\"start_search\" value=\"yes\">
                                <input type=\"hidden\" name=\"doQuery\" value=\"yes\">
                                <input type=\"submit\" value=\"{{ translator.getLang('Search') }}\">
                            </td>
                        </tr>
                    </table>
                </form>


                <!-- end content -->
            </div>

        </div>
        <!-- end widget div -->
    </div>
    <!-- end widget -->


</article>

<article class=\"col-sm-12 col-md-12 col-lg-12\">
    <!-- new widget -->
    <div class=\"jarviswidget jarviswidget-color-blueDark\" id=\"wid-id-1\" data-widget-editbutton=\"false\" data-widget-fullscreenbutton=\"false\">

    <style>
        div .label{
            color:#333!important;
        }
        div, td{
            text-align: left;
        }
    </style>

        <header>
            <span class=\"widget-icon\"> <i class=\"fa fa-comments txt-color-white\"></i> </span>
            <h2> {{ translator.getLang('Search results') }} </h2>
            <div class=\"widget-toolbar\">
                <!-- add: non-hidden - to disable auto hide -->


            </div>
        </header>

        <!-- widget div-->
        <div>
            <!-- widget edit box -->
            <div class=\"jarviswidget-editbox\">
                <div>
                    <label>Title:</label>
                    <input type=\"text\" />
                </div>
            </div>
            <!-- end widget edit box -->

            <div class=\"widget-body widget-hide-overflow no-padding\" id=\"searchResults\">
                <!-- content goes here -->




                <!-- end content -->
            </div>

        </div>
        <!-- end widget div -->
    </div>
    <!-- end widget -->


</article>

<script>
    \$(document).ready(function(){
        // \$.post(\"https://testadm.cspstar.com/services/jurisdiction_services.inc\",{action:\"7\",
        //     jur_id:\$(\"#jurisdictionFast\").val()
        // }, function(data){
        //     \$('#skinFast').text(data);
        // });

        \$('#searchUserForm').on('submit',function (e) {
            e.preventDefault();

            var data = \$(this).serializeArray();
            \$.ajax({
                url: '{{ path('user_search') }}',
                method: \"POST\",
                data: data,


            }).done(function (data) {
                console.log(data)
                if (data == 'expired') {
                    \$.bigBox({
                        title : \"{{ translator.getLang('Session expired') }}\",
                        content : \"{{ translator.getLang('Your session has expired, please login again') }}!\",
                        color : \"#C46A69\",
                        //timeout: 6000,
                        icon : \"fa fa-warning shake animated\",
                        number : \"1\",
                        timeout : 6000
                    });
                } else {
                    try {
                        \$.bigBox({
                            title : \"{{ translator.getLang('Success') }}\",
                            content : \"{{ translator.getLang('You registered a user') }}!\",
                            color : \"#76BA1B\",
                            //timeout: 6000,
                            icon : \"fa fa-thumbs-up shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        if (data == 0) {
                            \$('#addUserFastModal').modal('hide');

                            \$('#accountFastForm').closest('form').find(\"input[type=text]\").val(\"\");


                            //                                                window.location.href = '/login';
                        }

                        \$('#searchResults').empty().append(data)


                        if (data == -28) {

                        }

                        if (data != 0 && data != -28) {
                        }

                        return data;
                    }
                    catch (e) {
                        console.log(e);
                        \$.bigBox({
                            title : \"{{ translator.getLang('Error') }}\",
                            content : \"{{ translator.getLang('Something went wrong') }}!\",
                            color : \"#C46A69\",
                            //timeout: 6000,
                            icon : \"fa fa-warning shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        return false;
                    }
                }
            })
                .fail(function (error) {
                    console.log(error);
                    return false
                })
                .always(function () {
                    return false
                });
            return false;
        })
    })
</script>", "default/users/search.html.twig", "/srv/workspace/backofficenew/templates/default/users/search.html.twig");
    }
}
