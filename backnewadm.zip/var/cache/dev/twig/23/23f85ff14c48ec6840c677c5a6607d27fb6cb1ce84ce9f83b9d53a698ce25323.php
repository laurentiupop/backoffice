<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/index.html.twig */
class __TwigTemplate_ffffe29168eeb9cc324312b3a68505e7c1f845460fbf33ad633a84e81e2acbbb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        // line 2
        $context["bodyClass"] = ("actualpage_" . twig_trim_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 2, $this->source); })()), "request", [], "any", false, false, false, 2), "pathinfo", [], "any", false, false, false, 2), "/"));
        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        $this->loadTemplate("default/twig-styles/indexStyle.html.twig", "default/index.html.twig", 5)->display($context);
        // line 6
        echo "<div class=\"text-center\">

";
        // line 8
        if ((0 === twig_compare((isset($context["loggedUser"]) || array_key_exists("loggedUser", $context) ? $context["loggedUser"] : (function () { throw new RuntimeError('Variable "loggedUser" does not exist.', 8, $this->source); })()), ""))) {
            // line 9
            echo "    <form action=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
            echo "\" class=\"form-signin homeLoginForm\" enctype=\"multipart/form-data\"  autocomplete=\"off\" method=\"POST\">
        <input type=\"hidden\" name=\"do_login\" value=\"yes\"/>
        <input type=\"hidden\" name=\"challenge\" value=\"";
            // line 11
            echo twig_escape_filter($this->env, (isset($context["challenge"]) || array_key_exists("challenge", $context) ? $context["challenge"] : (function () { throw new RuntimeError('Variable "challenge" does not exist.', 11, $this->source); })()), "html", null, true);
            echo "\"/>
        <input type=\"hidden\" name=\"hashed_password\" value=\"false\"/>
        <img class=\"mb-3\" src=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/icons/admin-icon.png"), "html", null, true);
            echo "\" alt=\"\" width=\"72\" height=\"72\">
        <h1 class=\"h3 mb-3 font-weight-normal\">Sign in</h1>
        <label for=\"inputUsername\" class=\"sr-only\">Username</label>
        <input type=\"text\" id=\"inputUsername\" name=\"admin_username\" class=\"form-control my-1\" placeholder=\"Username\" required=\"\" autofocus=\"\">
        <label for=\"inputPassword\" class=\"sr-only\">Password</label>
        <input type=\"password\" id=\"inputPassword\" name=\"admin_password\" class=\"form-control my-1\" placeholder=\"Password\" required=\"\">


        <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Sign in</button>
        <p class=\"mt-3 mb-1 text-muted\">© ";
            // line 22
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
            echo "</p>
    </form>
</div>
    ";
        }
        // line 26
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 26,  93 => 22,  81 => 13,  76 => 11,  70 => 9,  68 => 8,  64 => 6,  62 => 5,  55 => 4,  47 => 1,  45 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% set bodyClass = 'actualpage_'~app.request.pathinfo|trim('/') %}

{% block body %}
{% include (\"default/twig-styles/indexStyle.html.twig\") %}
<div class=\"text-center\">

{% if loggedUser == '' %}
    <form action=\"{{ path('login') }}\" class=\"form-signin homeLoginForm\" enctype=\"multipart/form-data\"  autocomplete=\"off\" method=\"POST\">
        <input type=\"hidden\" name=\"do_login\" value=\"yes\"/>
        <input type=\"hidden\" name=\"challenge\" value=\"{{ challenge }}\"/>
        <input type=\"hidden\" name=\"hashed_password\" value=\"false\"/>
        <img class=\"mb-3\" src=\"{{ asset('img/icons/admin-icon.png') }}\" alt=\"\" width=\"72\" height=\"72\">
        <h1 class=\"h3 mb-3 font-weight-normal\">Sign in</h1>
        <label for=\"inputUsername\" class=\"sr-only\">Username</label>
        <input type=\"text\" id=\"inputUsername\" name=\"admin_username\" class=\"form-control my-1\" placeholder=\"Username\" required=\"\" autofocus=\"\">
        <label for=\"inputPassword\" class=\"sr-only\">Password</label>
        <input type=\"password\" id=\"inputPassword\" name=\"admin_password\" class=\"form-control my-1\" placeholder=\"Password\" required=\"\">


        <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Sign in</button>
        <p class=\"mt-3 mb-1 text-muted\">© {{ 'now' | date('Y') }}</p>
    </form>
</div>
    {% endif %}

{% endblock %}", "default/index.html.twig", "/srv/workspace/backofficenew/templates/default/index.html.twig");
    }
}
