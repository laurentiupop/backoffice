<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/users/fastRegister.html.twig */
class __TwigTemplate_ebc13b1028ef56fb39425c8549c8ffebc582d3eb745ae43998266838aa8e462b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/users/fastRegister.html.twig"));

        // line 1
        echo "

<article class=\"col-sm-12 col-md-12 col-lg-12\">
    <!-- new widget -->
    <div class=\"jarviswidget jarviswidget-color-blueDark\" id=\"wid-id-1\" data-widget-editbutton=\"false\" data-widget-fullscreenbutton=\"false\">

        <!-- widget options:
        usage: <div class=\"jarviswidget\" id=\"wid-id-0\" data-widget-editbutton=\"false\">

        data-widget-colorbutton=\"false\"
        data-widget-editbutton=\"false\"
        data-widget-togglebutton=\"false\"
        data-widget-deletebutton=\"false\"
        data-widget-fullscreenbutton=\"false\"
        data-widget-custombutton=\"false\"
        data-widget-collapsed=\"true\"
        data-widget-sortable=\"false\"

        -->

        <header>
            <span class=\"widget-icon\"> <i class=\"fa fa-comments txt-color-white\"></i> </span>
            <h2> ";
        // line 23
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 23, $this->source); })()), "getLang", [0 => "Fast registration"], "method", false, false, false, 23), "html", null, true);
        echo " </h2>
            <div class=\"widget-toolbar\">
                <!-- add: non-hidden - to disable auto hide -->


            </div>
        </header>

        <!-- widget div-->
        <div>
            <!-- widget edit box -->
            <div class=\"jarviswidget-editbox\">
                <div>
                    <label>Title:</label>
                    <input type=\"text\" />
                </div>
            </div>
            <!-- end widget edit box -->

            <div class=\"widget-body widget-hide-overflow no-padding\">
                <!-- content goes here -->

                <form action=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("fast_registration");
        echo "\" id=\"fastRegistrationForm\" name=\"preg_form\" class=\"smart-form client-form\">
                    <header>
                        Fast registration
                    </header>
                    <input type=hidden name=mode value=\"save\">
                    <input type=\"hidden\" name=\"section\" value=\"1\">
                    <fieldset>
                        <section>
                            <label class=\"text-align-left display-block\">";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 53, $this->source); })()), "getLang", [0 => "Username"], "method", false, false, false, 53), "html", null, true);
        echo "</label>
                            <label class=\"input\"> <i class=\"icon-append fa fa-user\"></i>
                                <input type=\"text\" name=\"username\" class=\"usrSrch\" size=40  value=\"\" >
                                <b class=\"tooltip tooltip-bottom-right\">";
        // line 56
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 56, $this->source); })()), "getLang", [0 => "Username"], "method", false, false, false, 56), "html", null, true);
        echo "</b> </label>
                        </section>

                        <section>
                            <label class=\"text-align-left display-block\">";
        // line 60
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 60, $this->source); })()), "getLang", [0 => "Password"], "method", false, false, false, 60), "html", null, true);
        echo "</label>
                            <label class=\"input\"> <i class=\"icon-append fa fa-envelope\"></i>
                                <input type=\"password\" name=\"password\" size=40  value=\"\">
                                <b class=\"tooltip tooltip-bottom-right\">";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 63, $this->source); })()), "getLang", [0 => "Password"], "method", false, false, false, 63), "html", null, true);
        echo "</b> </label>
                        </section>

                        <section>
                            <label class=\"text-align-left display-block\">";
        // line 67
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 67, $this->source); })()), "getLang", [0 => "Repeat password"], "method", false, false, false, 67), "html", null, true);
        echo "</label>
                            <label class=\"input\"> <i class=\"icon-append fa fa-lock\"></i>
                                <input type=\"password\" name=\"confirm_password\" size=40  value=\"\">
                                <b class=\"tooltip tooltip-bottom-right\">";
        // line 70
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 70, $this->source); })()), "getLang", [0 => "Repeat password"], "method", false, false, false, 70), "html", null, true);
        echo "</b> </label>
                        </section>

                        <section>
                            <label class=\"text-align-left display-block\">";
        // line 74
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 74, $this->source); })()), "getLang", [0 => "Jurisdiction"], "method", false, false, false, 74), "html", null, true);
        echo "</label>
                            <label class=\"select\"> <i class=\"icon-append fa fa-lock\"></i>
                                <select name='jurisdiction' id='jurisdictionFast'>
                                    ";
        // line 78
        echo "                                    ";
        // line 79
        echo "                                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["jurList"]) || array_key_exists("jurList", $context) ? $context["jurList"] : (function () { throw new RuntimeError('Variable "jurList" does not exist.', 79, $this->source); })()));
        foreach ($context['_seq'] as $context["v"] => $context["k"]) {
            // line 80
            echo "                                        ";
            // line 81
            echo "                                        <optgroup label=\"";
            echo twig_escape_filter($this->env, $context["v"], "html", null, true);
            echo "\">
                                            ";
            // line 83
            echo "                                            ";
            // line 84
            echo "                                            ";
            // line 85
            echo "                                            ";
            // line 86
            echo "                                            ";
            // line 87
            echo "
                                            ";
            // line 88
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["k"]);
            foreach ($context['_seq'] as $context["v2"] => $context["k2"]) {
                // line 89
                echo "                                                <option value='";
                echo twig_escape_filter($this->env, $context["v2"], "html", null, true);
                echo "' >";
                echo twig_escape_filter($this->env, $context["k2"], "html", null, true);
                echo "</option>
                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['v2'], $context['k2'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "                                        </optgroup>
                                        ";
            // line 93
            echo "                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['v'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 94
        echo "                                    ";
        // line 95
        echo "                                    ";
        // line 96
        echo "                                </select>
                                <b class=\"tooltip tooltip-bottom-right\"></b> </label>
                        </section>
                        <section style=\"text-align: left;\">
                            <label class=\"select\">";
        // line 100
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 100, $this->source); })()), "getLang", [0 => "Skin"], "method", false, false, false, 100), "html", null, true);
        echo " :</label>
                            <div id=\"skinFast\"></div>
                        </section>
                    </fieldset>

                    <footer>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            ";
        // line 107
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 107, $this->source); })()), "getLang", [0 => "Register"], "method", false, false, false, 107), "html", null, true);
        echo "
                        </button>
                    </footer>


                </form>

                <!-- end content -->
            </div>

        </div>
        <!-- end widget div -->
    </div>
    <!-- end widget -->


</article>

<script>
    \$(document).ready(function(){
        \$.post(\"https://testadm.cspstar.com/services/jurisdiction_services.inc\",{action:\"7\",
            jur_id:\$(\"#jurisdictionFast\").val()
        }, function(data){
            \$('#skinFast').text(data);
        });

        \$('#fastRegistrationForm').on('submit',function (e) {
            e.preventDefault();

            var data = \$(this).serializeArray();
            \$.ajax({
                url: '";
        // line 138
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("fast_registration");
        echo "',
                method: \"POST\",
                data: data,


            }).done(function (data) {
                console.log(data)
                if (data == 'expired') {
                    \$.bigBox({
                        title : \"";
        // line 147
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 147, $this->source); })()), "getLang", [0 => "Session expired"], "method", false, false, false, 147), "html", null, true);
        echo "\",
                        content : \"";
        // line 148
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 148, $this->source); })()), "getLang", [0 => "Your session has expired, please login again"], "method", false, false, false, 148), "html", null, true);
        echo "!\",
                        color : \"#C46A69\",
                        //timeout: 6000,
                        icon : \"fa fa-warning shake animated\",
                        number : \"1\",
                        timeout : 6000
                    });
                } else {
                    try {
                        \$.bigBox({
                            title : \"";
        // line 158
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 158, $this->source); })()), "getLang", [0 => "Success"], "method", false, false, false, 158), "html", null, true);
        echo "\",
                            content : \"";
        // line 159
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 159, $this->source); })()), "getLang", [0 => "You registered a user"], "method", false, false, false, 159), "html", null, true);
        echo "!\",
                            color : \"#76BA1B\",
                            //timeout: 6000,
                            icon : \"fa fa-thumbs-up shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        if (data == 0) {
                            \$('#addUserFastModal').modal('hide');

                            \$('#accountFastForm').closest('form').find(\"input[type=text]\").val(\"\");


                            //                                                window.location.href = '/login';
                        }
                        if (data == -28) {

                        }

                        if (data != 0 && data != -28) {
                        }

                        return data;
                    }
                    catch (e) {
                        console.log(e);
                        \$.bigBox({
                            title : \"";
        // line 186
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 186, $this->source); })()), "getLang", [0 => "Error"], "method", false, false, false, 186), "html", null, true);
        echo "\",
                            content : \"";
        // line 187
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 187, $this->source); })()), "getLang", [0 => "Something went wrong"], "method", false, false, false, 187), "html", null, true);
        echo "!\",
                            color : \"#C46A69\",
                            //timeout: 6000,
                            icon : \"fa fa-warning shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        return false;
                    }
                }
            })
                .fail(function (error) {
                    console.log(error);
                    return false
                })
                .always(function () {
                    return false
                });
            return false;
        })
    })
</script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/users/fastRegister.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  315 => 187,  311 => 186,  281 => 159,  277 => 158,  264 => 148,  260 => 147,  248 => 138,  214 => 107,  204 => 100,  198 => 96,  196 => 95,  194 => 94,  188 => 93,  185 => 91,  174 => 89,  170 => 88,  167 => 87,  165 => 86,  163 => 85,  161 => 84,  159 => 83,  154 => 81,  152 => 80,  147 => 79,  145 => 78,  139 => 74,  132 => 70,  126 => 67,  119 => 63,  113 => 60,  106 => 56,  100 => 53,  89 => 45,  64 => 23,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("

<article class=\"col-sm-12 col-md-12 col-lg-12\">
    <!-- new widget -->
    <div class=\"jarviswidget jarviswidget-color-blueDark\" id=\"wid-id-1\" data-widget-editbutton=\"false\" data-widget-fullscreenbutton=\"false\">

        <!-- widget options:
        usage: <div class=\"jarviswidget\" id=\"wid-id-0\" data-widget-editbutton=\"false\">

        data-widget-colorbutton=\"false\"
        data-widget-editbutton=\"false\"
        data-widget-togglebutton=\"false\"
        data-widget-deletebutton=\"false\"
        data-widget-fullscreenbutton=\"false\"
        data-widget-custombutton=\"false\"
        data-widget-collapsed=\"true\"
        data-widget-sortable=\"false\"

        -->

        <header>
            <span class=\"widget-icon\"> <i class=\"fa fa-comments txt-color-white\"></i> </span>
            <h2> {{ translator.getLang('Fast registration') }} </h2>
            <div class=\"widget-toolbar\">
                <!-- add: non-hidden - to disable auto hide -->


            </div>
        </header>

        <!-- widget div-->
        <div>
            <!-- widget edit box -->
            <div class=\"jarviswidget-editbox\">
                <div>
                    <label>Title:</label>
                    <input type=\"text\" />
                </div>
            </div>
            <!-- end widget edit box -->

            <div class=\"widget-body widget-hide-overflow no-padding\">
                <!-- content goes here -->

                <form action=\"{{ path('fast_registration') }}\" id=\"fastRegistrationForm\" name=\"preg_form\" class=\"smart-form client-form\">
                    <header>
                        Fast registration
                    </header>
                    <input type=hidden name=mode value=\"save\">
                    <input type=\"hidden\" name=\"section\" value=\"1\">
                    <fieldset>
                        <section>
                            <label class=\"text-align-left display-block\">{{ translator.getLang('Username') }}</label>
                            <label class=\"input\"> <i class=\"icon-append fa fa-user\"></i>
                                <input type=\"text\" name=\"username\" class=\"usrSrch\" size=40  value=\"\" >
                                <b class=\"tooltip tooltip-bottom-right\">{{ translator.getLang('Username') }}</b> </label>
                        </section>

                        <section>
                            <label class=\"text-align-left display-block\">{{ translator.getLang('Password') }}</label>
                            <label class=\"input\"> <i class=\"icon-append fa fa-envelope\"></i>
                                <input type=\"password\" name=\"password\" size=40  value=\"\">
                                <b class=\"tooltip tooltip-bottom-right\">{{ translator.getLang('Password') }}</b> </label>
                        </section>

                        <section>
                            <label class=\"text-align-left display-block\">{{ translator.getLang('Repeat password') }}</label>
                            <label class=\"input\"> <i class=\"icon-append fa fa-lock\"></i>
                                <input type=\"password\" name=\"confirm_password\" size=40  value=\"\">
                                <b class=\"tooltip tooltip-bottom-right\">{{ translator.getLang('Repeat password') }}</b> </label>
                        </section>

                        <section>
                            <label class=\"text-align-left display-block\">{{ translator.getLang('Jurisdiction') }}</label>
                            <label class=\"select\"> <i class=\"icon-append fa fa-lock\"></i>
                                <select name='jurisdiction' id='jurisdictionFast'>
                                    {#<?#}
                                    {#foreach(\$clubs as \$k=>\$v){#}
                                    {% for v,k in  jurList%}
                                        {#?>#}
                                        <optgroup label=\"{{ v }}\">
                                            {#{% for v2,k2 in k %}#}
                                            {#{% if v2 == 'club_name' %}#}
                                            {#<option value='{{ k.club_id }}' >{{ k2 }}</option>#}
                                            {#{% endif %}#}
                                            {#{% endfor %}#}

                                            {% for v2,k2 in k %}
                                                <option value='{{ v2 }}' >{{ k2 }}</option>
                                            {% endfor %}
                                        </optgroup>
                                        {#<?#}
                                    {% endfor %}
                                    {#}#}
                                    {#?>#}
                                </select>
                                <b class=\"tooltip tooltip-bottom-right\"></b> </label>
                        </section>
                        <section style=\"text-align: left;\">
                            <label class=\"select\">{{ translator.getLang('Skin') }} :</label>
                            <div id=\"skinFast\"></div>
                        </section>
                    </fieldset>

                    <footer>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            {{ translator.getLang('Register') }}
                        </button>
                    </footer>


                </form>

                <!-- end content -->
            </div>

        </div>
        <!-- end widget div -->
    </div>
    <!-- end widget -->


</article>

<script>
    \$(document).ready(function(){
        \$.post(\"https://testadm.cspstar.com/services/jurisdiction_services.inc\",{action:\"7\",
            jur_id:\$(\"#jurisdictionFast\").val()
        }, function(data){
            \$('#skinFast').text(data);
        });

        \$('#fastRegistrationForm').on('submit',function (e) {
            e.preventDefault();

            var data = \$(this).serializeArray();
            \$.ajax({
                url: '{{ path('fast_registration') }}',
                method: \"POST\",
                data: data,


            }).done(function (data) {
                console.log(data)
                if (data == 'expired') {
                    \$.bigBox({
                        title : \"{{ translator.getLang('Session expired') }}\",
                        content : \"{{ translator.getLang('Your session has expired, please login again') }}!\",
                        color : \"#C46A69\",
                        //timeout: 6000,
                        icon : \"fa fa-warning shake animated\",
                        number : \"1\",
                        timeout : 6000
                    });
                } else {
                    try {
                        \$.bigBox({
                            title : \"{{ translator.getLang('Success') }}\",
                            content : \"{{ translator.getLang('You registered a user') }}!\",
                            color : \"#76BA1B\",
                            //timeout: 6000,
                            icon : \"fa fa-thumbs-up shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        if (data == 0) {
                            \$('#addUserFastModal').modal('hide');

                            \$('#accountFastForm').closest('form').find(\"input[type=text]\").val(\"\");


                            //                                                window.location.href = '/login';
                        }
                        if (data == -28) {

                        }

                        if (data != 0 && data != -28) {
                        }

                        return data;
                    }
                    catch (e) {
                        console.log(e);
                        \$.bigBox({
                            title : \"{{ translator.getLang('Error') }}\",
                            content : \"{{ translator.getLang('Something went wrong') }}!\",
                            color : \"#C46A69\",
                            //timeout: 6000,
                            icon : \"fa fa-warning shake animated\",
                            number : \"1\",
                            timeout : 6000
                        });
                        return false;
                    }
                }
            })
                .fail(function (error) {
                    console.log(error);
                    return false
                })
                .always(function () {
                    return false
                });
            return false;
        })
    })
</script>", "default/users/fastRegister.html.twig", "/srv/workspace/backofficenew/templates/default/users/fastRegister.html.twig");
    }
}
