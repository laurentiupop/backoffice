<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/base_structure/head.html.twig */
class __TwigTemplate_ee953977dc6e8246a358552dafd82db67923ede5f795ff3bd523d86554b03dea extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/base_structure/head.html.twig"));

        // line 2
        echo "<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
<meta name=\"description\" content=\"\">
<meta name=\"author\" content=\"\">

<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/project-css/base-css/colors.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/project-css/base-css/style.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/external-css/bootstrap.min.css"), "html", null, true);
        echo "\">";
        // line 14
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/extern-plugins/jquery-3-5-1.min.js"), "html", null, true);
        echo "\"></script>";
        // line 16
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/extern-plugins/jquery-ui-1.11.4.min.js"), "html", null, true);
        echo "\"></script>";
        // line 18
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/extern-plugins/bootstrap.min.js"), "html", null, true);
        echo "\"></script>";
        // line 20
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/extern-plugins/bootstrap-bundle.min.js"), "html", null, true);
        echo "\"></script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/base_structure/head.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 20,  66 => 18,  62 => 16,  58 => 14,  55 => 9,  51 => 8,  47 => 7,  40 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{#--- Style ---#}
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
<meta name=\"description\" content=\"\">
<meta name=\"author\" content=\"\">

<link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('css/project-css/base-css/colors.css') }}\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('css/project-css/base-css/style.css') }}\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('css/external-css/bootstrap.min.css') }}\">
{#--- End Style ---#}

{#--- Scripts ---#}
{# --- jQuery 3.5.1 ---#}
<script src=\"{{ asset('js/extern-plugins/jquery-3-5-1.min.js') }}\"></script>
{#--- jQuety UI 1.11.4 ---#}
<script src=\"{{ asset('js/extern-plugins/jquery-ui-1.11.4.min.js') }}\"></script>
{#--- bootstrap 4 ---#}
<script src=\"{{ asset('js/extern-plugins/bootstrap.min.js') }}\"></script>
{#--- bootstrap bundle ---#}
<script src=\"{{ asset('js/extern-plugins/bootstrap-bundle.min.js') }}\"></script>
{#--- End scripts ---#}", "default/base_structure/head.html.twig", "/srv/workspace/backofficenew/templates/default/base_structure/head.html.twig");
    }
}
