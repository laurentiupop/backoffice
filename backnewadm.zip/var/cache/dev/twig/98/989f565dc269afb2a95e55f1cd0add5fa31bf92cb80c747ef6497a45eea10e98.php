<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/base_structure/footer.html.twig */
class __TwigTemplate_dfe775afafcedbc75e5434f8855bdc2e7e1df3e7460109e311d2ba4e63bea8b0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/base_structure/footer.html.twig"));

        // line 1
        echo "<!-- PAGE FOOTER -->
<div class=\"page-footer\">
\t<div class=\"row\">
\t\t<div class=\"col-xs-12 col-sm-6\">
\t\t\t<span class=\"txt-color-white\">Admin <span class=\"hidden-xs\"> - </span> © ";
        // line 5
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo "</span>
\t\t</div>

\t\t<div class=\"col-xs-6 col-sm-6 text-right hidden-xs\">
\t\t\t<div class=\"txt-color-white inline-block\">
\t\t\t\t<i class=\"txt-color-blueLight hidden-mobile\">Last account activity <i class=\"fa fa-clock-o\"></i> <strong>52 mins ago &nbsp;</strong> </i>
\t\t\t\t<div class=\"btn-group dropup\">
\t\t\t\t\t<button class=\"btn btn-xs dropdown-toggle bg-color-blue txt-color-white\" data-toggle=\"dropdown\">
\t\t\t\t\t\t<i class=\"fa fa-link\"></i> <span class=\"caret\"></span>
\t\t\t\t\t</button>
\t\t\t\t\t<ul class=\"dropdown-menu pull-right text-left\">
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<p class=\"txt-color-darken font-sm no-margin\">Download Progress</p>
\t\t\t\t\t\t\t\t<div class=\"progress progress-micro no-margin\">
\t\t\t\t\t\t\t\t\t<div class=\"progress-bar progress-bar-success\" style=\"width: 50%;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<p class=\"txt-color-darken font-sm no-margin\">Server Load</p>
\t\t\t\t\t\t\t\t<div class=\"progress progress-micro no-margin\">
\t\t\t\t\t\t\t\t\t<div class=\"progress-bar progress-bar-success\" style=\"width: 20%;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<p class=\"txt-color-darken font-sm no-margin\">Memory Load <span class=\"text-danger\">*critical*</span></p>
\t\t\t\t\t\t\t\t<div class=\"progress progress-micro no-margin\">
\t\t\t\t\t\t\t\t\t<div class=\"progress-bar progress-bar-danger\" style=\"width: 70%;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-block btn-default\">refresh</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t</ul>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
<!-- END PAGE FOOTER -->

<!-- SHORTCUT AREA : With large tiles (activated via clicking user name tag)
Note: These tiles are completely responsive,
you can add as many as you like
-->
<div id=\"shortcut\">
\t<ul class=\"leftUl\">
\t\t<li class=\"leftLi\">
            <div class=\"creditField\">";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["translator"]) || array_key_exists("translator", $context) ? $context["translator"] : (function () { throw new RuntimeError('Variable "translator" does not exist.', 63, $this->source); })()), "getLang", [0 => "Credit"], "method", false, false, false, 63), "html", null, true);
        echo " : ";
        echo twig_escape_filter($this->env, (isset($context["credit"]) || array_key_exists("credit", $context) ? $context["credit"] : (function () { throw new RuntimeError('Variable "credit" does not exist.', 63, $this->source); })()), "html", null, true);
        echo (isset($context["currency"]) || array_key_exists("currency", $context) ? $context["currency"] : (function () { throw new RuntimeError('Variable "currency" does not exist.', 63, $this->source); })());
        echo "</div>
\t\t</li>

\t\t";
        // line 67
        echo "\t\t</li>
\t</ul>
</div>
<!-- END SHORTCUT AREA -->
<!-- MAIN APP JS FILE -->
<!-- PACE LOADER - turn this on if you want ajax loading to show (caution: uses lots of memory on iDevices)-->
<script data-pace-options='{ \"restartOnRequestAfter\": true }' src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/pace/pace.min.js"), "html", null, true);
        echo "\"></script>



<!-- IMPORTANT: APP CONFIG -->
<script src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/app.config.js"), "html", null, true);
        echo "\"></script>

<!-- JS TOUCH : include this plugin for mobile drag / drop touch events-->
<script src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/jquery-touch/jquery.ui.touch-punch.min.js"), "html", null, true);
        echo "\"></script>

<!-- BOOTSTRAP JS -->
<script src=\"";
        // line 84
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/bootstrap/bootstrap.min.js"), "html", null, true);
        echo "\"></script>

<!-- CUSTOM NOTIFICATION -->
<script src=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/notification/SmartNotification.min.js"), "html", null, true);
        echo "\"></script>

<!-- JARVIS WIDGETS -->
<script src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/smartwidgets/jarvis.widget.min.js"), "html", null, true);
        echo "\"></script>

<!-- EASY PIE CHARTS -->
<script src=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js"), "html", null, true);
        echo "\"></script>

<!-- SPARKLINES -->
<script src=\"";
        // line 96
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/sparkline/jquery.sparkline.min.js"), "html", null, true);
        echo "\"></script>

<!-- JQUERY VALIDATE -->
<script src=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/jquery-validate/jquery.validate.min.js"), "html", null, true);
        echo "\"></script>

<!-- JQUERY MASKED INPUT -->
<script src=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/masked-input/jquery.maskedinput.min.js"), "html", null, true);
        echo "\"></script>

<!-- JQUERY SELECT2 INPUT -->
<script src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/select2/select2.min.js"), "html", null, true);
        echo "\"></script>

<!-- JQUERY UI + Bootstrap Slider -->
<script src=\"";
        // line 108
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/bootstrap-slider/bootstrap-slider.min.js"), "html", null, true);
        echo "\"></script>

<!-- browser msie issue fix -->
<script src=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/msie-fix/jquery.mb.browser.min.js"), "html", null, true);
        echo "\"></script>

<!-- FastClick: For mobile devices -->
<script src=\"";
        // line 114
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/fastclick/fastclick.min.js"), "html", null, true);
        echo "\"></script>

<!--[if IE 8]>

<h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>

<![endif]-->

<!-- Demo purpose only -->
<script src=\"";
        // line 123
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/demo.min.js"), "html", null, true);
        echo "\"></script>



<!-- ENHANCEMENT PLUGINS : NOT A REQUIREMENT -->
<!-- Voice command : plugin -->
<script src=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/speech/voicecommand.min.js"), "html", null, true);
        echo "\"></script>

<!-- SmartChat UI : plugin -->
<script src=\"";
        // line 132
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/smart-chat-ui/smart.chat.ui.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/smart-chat-ui/smart.chat.manager.min.js"), "html", null, true);
        echo "\"></script>

<!-- PAGE RELATED PLUGIN(S) -->

<!-- Flot Chart Plugin: Flot Engine, Flot Resizer, Flot Tooltip -->
<script src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/flot/jquery.flot.cust.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 139
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/flot/jquery.flot.resize.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 140
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/flot/jquery.flot.time.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 141
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/flot/jquery.flot.tooltip.min.js"), "html", null, true);
        echo "\"></script>

<!-- Vector Maps Plugin: Vectormap engine, Vectormap language -->
<script src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/vectormap/jquery-jvectormap-1.2.2.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 145
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/vectormap/jquery-jvectormap-world-mill-en.js"), "html", null, true);
        echo "\"></script>

<!-- Full Calendar -->
<script src=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/moment/moment.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/plugin/fullcalendar/jquery.fullcalendar.min.js"), "html", null, true);
        echo "\"></script>
<script>
\t\$(document).ready(function(){
\t    \$('.top-menu-invisible li').on('click', function () {
\t\t\t\$('.top-menu-invisible li').removeClass('active')
\t\t\t\$(this).addClass('active')

\t\t\t\$('#subSectionName').text(\$(this).text())
        })
\t\t
\t\t\$('.sectionNm').on('click', function () {
\t\t\t\$('#sectionName').text(\$(this).text())
        })
\t})
</script>
<script>
    \$(document).ready(function() {

        // DO NOT REMOVE : GLOBAL FUNCTIONS!
        pageSetUp();

        /*
         * PAGE RELATED SCRIPTS
         */

        \$(\".js-status-update a\").click(function() {
            var selText = \$(this).text();
            var \$this = \$(this);
            \$this.parents('.btn-group').find('.dropdown-toggle').html(selText + ' <span class=\"caret\"></span>');
            \$this.parents('.dropdown-menu').find('li').removeClass('active');
            \$this.parent().addClass('active');
        });

        /*
        * TODO: add a way to add more todo's to list
        */

        // initialize sortable
        \$(function() {
            \$(\"#sortable1, #sortable2\").sortable({
                handle : '.handle',
                connectWith : \".todo\",
                update : countTasks
            }).disableSelection();
        });

        // check and uncheck
        \$('.todo .checkbox > input[type=\"checkbox\"]').click(function() {
            var \$this = \$(this).parent().parent().parent();

            if (\$(this).prop('checked')) {
                \$this.addClass(\"complete\");

                // remove this if you want to undo a check list once checked
                //\$(this).attr(\"disabled\", true);
                \$(this).parent().hide();

                // once clicked - add class, copy to memory then remove and add to sortable3
                \$this.slideUp(500, function() {
                    \$this.clone().prependTo(\"#sortable3\").effect(\"highlight\", {}, 800);
                    \$this.remove();
                    countTasks();
                });
            } else {
                // insert undo code here...
            }

        })
        // count tasks
        function countTasks() {

            \$('.todo-group-title').each(function() {
                var \$this = \$(this);
                \$this.find(\".num-of-tasks\").text(\$this.next().find(\"li\").size());
            });

        }

        ";
        // line 228
        echo "        ";
        // line 229
        echo "        ";
        // line 230
        echo "        ";
        // line 231
        echo "
        ";
        // line 233
        echo "        ";
        // line 234
        echo "
        ";
        // line 236
        echo "
        ";
        // line 238
        echo "        ";
        // line 239
        echo "        ";
        // line 240
        echo "
        ";
        // line 242
        echo "        ";
        // line 243
        echo "        ";
        // line 244
        echo "        ";
        // line 245
        echo "        ";
        // line 246
        echo "        ";
        // line 247
        echo "        ";
        // line 248
        echo "        ";
        // line 249
        echo "        ";
        // line 250
        echo "        ";
        // line 251
        echo "
        ";
        // line 253
        echo "        ";
        // line 254
        echo "        ";
        // line 255
        echo "        ";
        // line 256
        echo "        ";
        // line 257
        echo "        ";
        // line 258
        echo "
        ";
        // line 260
        echo "        ";
        // line 261
        echo "        ";
        // line 262
        echo "
        ";
        // line 264
        echo "        ";
        // line 265
        echo "        ";
        // line 266
        echo "        ";
        // line 267
        echo "        ";
        // line 268
        echo "
        ";
        // line 270
        echo "
        ";
        // line 272
        echo "        ";
        // line 273
        echo "        ";
        // line 274
        echo "        ";
        // line 275
        echo "        ";
        // line 276
        echo "        ";
        // line 277
        echo "        ";
        // line 278
        echo "        ";
        // line 279
        echo "        ";
        // line 280
        echo "        ";
        // line 281
        echo "        ";
        // line 282
        echo "        ";
        // line 283
        echo "        ";
        // line 284
        echo "        ";
        // line 285
        echo "        ";
        // line 286
        echo "        ";
        // line 287
        echo "        ";
        // line 288
        echo "        ";
        // line 289
        echo "        ";
        // line 290
        echo "        ";
        // line 291
        echo "        ";
        // line 292
        echo "        ";
        // line 293
        echo "        ";
        // line 294
        echo "
        ";
        // line 296
        echo "        ";
        // line 297
        echo "        ";
        // line 298
        echo "
        ";
        // line 300
        echo "
        ";
        // line 302
        echo "        ";
        // line 303
        echo "        ";
        // line 304
        echo "        ";
        // line 305
        echo "        ";
        // line 306
        echo "        ";
        // line 307
        echo "        ";
        // line 308
        echo "        ";
        // line 309
        echo "        ";
        // line 310
        echo "        ";
        // line 311
        echo "        ";
        // line 312
        echo "
        ";
        // line 314
        echo "        ";
        // line 315
        echo "        ";
        // line 316
        echo "        ";
        // line 317
        echo "        ";
        // line 318
        echo "
        ";
        // line 320
        echo "        ";
        // line 321
        echo "        ";
        // line 322
        echo "
        ";
        // line 324
        echo "
        ";
        // line 326
        echo "
        ";
        // line 328
        echo "
        ";
        // line 330
        echo "
        ";
        // line 332
        echo "        ";
        // line 333
        echo "        ";
        // line 334
        echo "        ";
        // line 335
        echo "        ";
        // line 336
        echo "        ";
        // line 337
        echo "        ";
        // line 338
        echo "        ";
        // line 339
        echo "        ";
        // line 340
        echo "        ";
        // line 341
        echo "        ";
        // line 342
        echo "        ";
        // line 343
        echo "        ";
        // line 344
        echo "        ";
        // line 345
        echo "        ";
        // line 346
        echo "        ";
        // line 347
        echo "        ";
        // line 348
        echo "        ";
        // line 349
        echo "        ";
        // line 350
        echo "        ";
        // line 351
        echo "        ";
        // line 352
        echo "        ";
        // line 353
        echo "        ";
        // line 354
        echo "        ";
        // line 355
        echo "        ";
        // line 356
        echo "        ";
        // line 357
        echo "        ";
        // line 358
        echo "        ";
        // line 359
        echo "        ";
        // line 360
        echo "        ";
        // line 361
        echo "        ";
        // line 362
        echo "        ";
        // line 363
        echo "        ";
        // line 364
        echo "        ";
        // line 365
        echo "        ";
        // line 366
        echo "        ";
        // line 367
        echo "        ";
        // line 368
        echo "        ";
        // line 369
        echo "        ";
        // line 370
        echo "
        ";
        // line 372
        echo "        ";
        // line 373
        echo "        ";
        // line 374
        echo "        ";
        // line 375
        echo "        ";
        // line 376
        echo "        ";
        // line 377
        echo "        ";
        // line 378
        echo "        ";
        // line 379
        echo "        ";
        // line 380
        echo "        ";
        // line 381
        echo "        ";
        // line 382
        echo "        ";
        // line 383
        echo "        ";
        // line 384
        echo "        ";
        // line 385
        echo "
        ";
        // line 387
        echo "        ";
        // line 388
        echo "
        ";
        // line 390
        echo "        ";
        // line 391
        echo "
        ";
        // line 393
        echo "
        ";
        // line 395
        echo "        ";
        // line 396
        echo "
        ";
        // line 398
        echo "
        ";
        // line 400
        echo "
        ";
        // line 402
        echo "        ";
        // line 403
        echo "        ";
        // line 404
        echo "        ";
        // line 405
        echo "        ";
        // line 406
        echo "        ";
        // line 407
        echo "        ";
        // line 408
        echo "        ";
        // line 409
        echo "        ";
        // line 410
        echo "        ";
        // line 411
        echo "        ";
        // line 412
        echo "        ";
        // line 413
        echo "        ";
        // line 414
        echo "        ";
        // line 415
        echo "        ";
        // line 416
        echo "        ";
        // line 417
        echo "        ";
        // line 418
        echo "        ";
        // line 419
        echo "        ";
        // line 420
        echo "        ";
        // line 421
        echo "        ";
        // line 422
        echo "        ";
        // line 423
        echo "        ";
        // line 424
        echo "        ";
        // line 425
        echo "        ";
        // line 426
        echo "        ";
        // line 427
        echo "        ";
        // line 428
        echo "        ";
        // line 429
        echo "        ";
        // line 430
        echo "        ";
        // line 431
        echo "        ";
        // line 432
        echo "
        ";
        // line 434
        echo "        ";
        // line 435
        echo "        ";
        // line 436
        echo "        ";
        // line 437
        echo "        ";
        // line 438
        echo "        ";
        // line 439
        echo "        ";
        // line 440
        echo "        ";
        // line 441
        echo "        ";
        // line 442
        echo "        ";
        // line 443
        echo "        ";
        // line 444
        echo "        ";
        // line 445
        echo "        ";
        // line 446
        echo "        ";
        // line 447
        echo "        ";
        // line 448
        echo "        ";
        // line 449
        echo "        ";
        // line 450
        echo "        ";
        // line 451
        echo "        ";
        // line 452
        echo "
        ";
        // line 454
        echo "
        ";
        // line 456
        echo "
        ";
        // line 458
        echo "        ";
        // line 459
        echo "        ";
        // line 460
        echo "        ";
        // line 461
        echo "        ";
        // line 462
        echo "        ";
        // line 463
        echo "        ";
        // line 464
        echo "        ";
        // line 465
        echo "        ";
        // line 466
        echo "        ";
        // line 467
        echo "        ";
        // line 468
        echo "        ";
        // line 469
        echo "        ";
        // line 470
        echo "        ";
        // line 471
        echo "        ";
        // line 472
        echo "
        ";
        // line 474
        echo "
        ";
        // line 476
        echo "        ";
        // line 477
        echo "        ";
        // line 478
        echo "        ";
        // line 479
        echo "
        ";
        // line 481
        echo "
        ";
        // line 483
        echo "        ";
        // line 484
        echo "        ";
        // line 485
        echo "
        ";
        // line 487
        echo "        ";
        // line 488
        echo "        ";
        // line 489
        echo "        ";
        // line 490
        echo "        ";
        // line 491
        echo "        ";
        // line 492
        echo "        ";
        // line 493
        echo "        ";
        // line 494
        echo "        ";
        // line 495
        echo "        ";
        // line 496
        echo "
        ";
        // line 498
        echo "        ";
        // line 499
        echo "        ";
        // line 500
        echo "        ";
        // line 501
        echo "        ";
        // line 502
        echo "        ";
        // line 503
        echo "        ";
        // line 504
        echo "        ";
        // line 505
        echo "        ";
        // line 506
        echo "        ";
        // line 507
        echo "        ";
        // line 508
        echo "        ";
        // line 509
        echo "        ";
        // line 510
        echo "        ";
        // line 511
        echo "        ";
        // line 512
        echo "        ";
        // line 513
        echo "        ";
        // line 514
        echo "        ";
        // line 515
        echo "        ";
        // line 516
        echo "        ";
        // line 517
        echo "        ";
        // line 518
        echo "        ";
        // line 519
        echo "        ";
        // line 520
        echo "        ";
        // line 521
        echo "        ";
        // line 522
        echo "        ";
        // line 523
        echo "        ";
        // line 524
        echo "
        ";
        // line 526
        echo "        ";
        // line 527
        echo "        ";
        // line 528
        echo "
        ";
        // line 530
        echo "        ";
        // line 531
        echo "        ";
        // line 532
        echo "        ";
        // line 533
        echo "        ";
        // line 534
        echo "
        ";
        // line 536
        echo "
        ";
        // line 538
        echo "        ";
        // line 539
        echo "        ";
        // line 540
        echo "        ";
        // line 541
        echo "        ";
        // line 542
        echo "        ";
        // line 543
        echo "        ";
        // line 544
        echo "
        ";
        // line 546
        echo "        ";
        // line 547
        echo "        ";
        // line 548
        echo "        ";
        // line 549
        echo "        ";
        // line 550
        echo "
        ";
        // line 552
        echo "        ";
        // line 553
        echo "        ";
        // line 554
        echo "        ";
        // line 555
        echo "        ";
        // line 556
        echo "        ";
        // line 557
        echo "        ";
        // line 558
        echo "        ";
        // line 559
        echo "        ";
        // line 560
        echo "        ";
        // line 561
        echo "        ";
        // line 562
        echo "        ";
        // line 563
        echo "        ";
        // line 564
        echo "
        ";
        // line 566
        echo "        ";
        // line 567
        echo "        ";
        // line 568
        echo "        ";
        // line 569
        echo "        ";
        // line 570
        echo "        ";
        // line 571
        echo "        ";
        // line 572
        echo "        ";
        // line 573
        echo "        ";
        // line 574
        echo "        ";
        // line 575
        echo "        ";
        // line 576
        echo "        ";
        // line 577
        echo "        ";
        // line 578
        echo "        ";
        // line 579
        echo "        ";
        // line 580
        echo "        ";
        // line 581
        echo "        ";
        // line 582
        echo "        ";
        // line 583
        echo "        ";
        // line 584
        echo "        ";
        // line 585
        echo "        ";
        // line 586
        echo "        ";
        // line 587
        echo "        ";
        // line 588
        echo "        ";
        // line 589
        echo "        ";
        // line 590
        echo "        ";
        // line 591
        echo "        ";
        // line 592
        echo "        ";
        // line 593
        echo "        ";
        // line 594
        echo "        ";
        // line 595
        echo "        ";
        // line 596
        echo "        ";
        // line 597
        echo "        ";
        // line 598
        echo "        ";
        // line 599
        echo "        ";
        // line 600
        echo "        ";
        // line 601
        echo "        ";
        // line 602
        echo "        ";
        // line 603
        echo "        ";
        // line 604
        echo "        ";
        // line 605
        echo "        ";
        // line 606
        echo "        ";
        // line 607
        echo "        ";
        // line 608
        echo "        ";
        // line 609
        echo "        ";
        // line 610
        echo "        ";
        // line 611
        echo "        ";
        // line 612
        echo "        ";
        // line 613
        echo "        ";
        // line 614
        echo "

        ";
        // line 617
        echo "        ";
        // line 618
        echo "        ";
        // line 619
        echo "        ";
        // line 620
        echo "        ";
        // line 621
        echo "        ";
        // line 622
        echo "        ";
        // line 623
        echo "        ";
        // line 624
        echo "        ";
        // line 625
        echo "
        ";
        // line 627
        echo "
        ";
        // line 629
        echo "        ";
        // line 630
        echo "
        ";
        // line 632
        echo "        ";
        // line 633
        echo "        ";
        // line 634
        echo "        ";
        // line 635
        echo "        ";
        // line 636
        echo "
        ";
        // line 638
        echo "        ";
        // line 639
        echo "        ";
        // line 640
        echo "        ";
        // line 641
        echo "        ";
        // line 642
        echo "
        ";
        // line 644
        echo "        ";
        // line 645
        echo "        ";
        // line 646
        echo "        ";
        // line 647
        echo "        ";
        // line 648
        echo "
        ";
        // line 650
        echo "        ";
        // line 651
        echo "        ";
        // line 652
        echo "        ";
        // line 653
        echo "
        ";
        // line 655
        echo "        ";
        // line 656
        echo "        ";
        // line 657
        echo "        ";
        // line 658
        echo "
        ";
        // line 660
        echo "        ";
        // line 661
        echo "        ";
        // line 662
        echo "        ";
        // line 663
        echo "
        ";
        // line 665
        echo "        ";
        // line 666
        echo "        ";
        // line 667
        echo "
        ";
        // line 669
        echo "        ";
        // line 670
        echo "        ";
        // line 671
        echo "        ";
        // line 672
        echo "        ";
        // line 673
        echo "
        ";
        // line 675
        echo "        ";
        // line 676
        echo "        ";
        // line 677
        echo "
        ";
        // line 679
        echo "        ";
        // line 680
        echo "        ";
        // line 681
        echo "        ";
        // line 682
        echo "
        ";
        // line 684
        echo "        ";
        // line 685
        echo "
        ";
        // line 687
        echo "        ";
        // line 688
        echo "        ";
        // line 689
        echo "        ";
        // line 690
        echo "        ";
        // line 691
        echo "        ";
        // line 692
        echo "        ";
        // line 693
        echo "        ";
        // line 694
        echo "        ";
        // line 695
        echo "        ";
        // line 696
        echo "        ";
        // line 697
        echo "        ";
        // line 698
        echo "        ";
        // line 699
        echo "        ";
        // line 700
        echo "
        ";
        // line 702
        echo "
        ";
        // line 704
        echo "
        ";
        // line 706
        echo "        ";
        // line 707
        echo "
        ";
        // line 709
        echo "        ";
        // line 710
        echo "        ";
        // line 711
        echo "        ";
        // line 712
        echo "
        ";
        // line 714
        echo "        ";
        // line 715
        echo "        ";
        // line 716
        echo "        ";
        // line 717
        echo "
    });

</script>

<!-- Your GOOGLE ANALYTICS CODE Below -->
<script type=\"text/javascript\">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
    _gaq.push(['_trackPageview']);

    (function() {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();

</script>

<!-- IMPORTANT: APP CONFIG -->
<script src=\"";
        // line 740
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/app.config.js"), "html", null, true);
        echo "\"></script>
<!-- CUSTOM NOTIFICATION -->
<script src=\"";
        // line 742
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/notification/SmartNotification.min.js"), "html", null, true);
        echo "\"></script>

<!-- JARVIS WIDGETS -->
<script src=\"";
        // line 745
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/smartwidgets/jarvis.widget.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 746
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/app.min.js"), "html", null, true);
        echo "\"></script>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/base_structure/footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1309 => 746,  1305 => 745,  1299 => 742,  1294 => 740,  1269 => 717,  1267 => 716,  1265 => 715,  1263 => 714,  1260 => 712,  1258 => 711,  1256 => 710,  1254 => 709,  1251 => 707,  1249 => 706,  1246 => 704,  1243 => 702,  1240 => 700,  1238 => 699,  1236 => 698,  1234 => 697,  1232 => 696,  1230 => 695,  1228 => 694,  1226 => 693,  1224 => 692,  1222 => 691,  1220 => 690,  1218 => 689,  1216 => 688,  1214 => 687,  1211 => 685,  1209 => 684,  1206 => 682,  1204 => 681,  1202 => 680,  1200 => 679,  1197 => 677,  1195 => 676,  1193 => 675,  1190 => 673,  1188 => 672,  1186 => 671,  1184 => 670,  1182 => 669,  1179 => 667,  1177 => 666,  1175 => 665,  1172 => 663,  1170 => 662,  1168 => 661,  1166 => 660,  1163 => 658,  1161 => 657,  1159 => 656,  1157 => 655,  1154 => 653,  1152 => 652,  1150 => 651,  1148 => 650,  1145 => 648,  1143 => 647,  1141 => 646,  1139 => 645,  1137 => 644,  1134 => 642,  1132 => 641,  1130 => 640,  1128 => 639,  1126 => 638,  1123 => 636,  1121 => 635,  1119 => 634,  1117 => 633,  1115 => 632,  1112 => 630,  1110 => 629,  1107 => 627,  1104 => 625,  1102 => 624,  1100 => 623,  1098 => 622,  1096 => 621,  1094 => 620,  1092 => 619,  1090 => 618,  1088 => 617,  1084 => 614,  1082 => 613,  1080 => 612,  1078 => 611,  1076 => 610,  1074 => 609,  1072 => 608,  1070 => 607,  1068 => 606,  1066 => 605,  1064 => 604,  1062 => 603,  1060 => 602,  1058 => 601,  1056 => 600,  1054 => 599,  1052 => 598,  1050 => 597,  1048 => 596,  1046 => 595,  1044 => 594,  1042 => 593,  1040 => 592,  1038 => 591,  1036 => 590,  1034 => 589,  1032 => 588,  1030 => 587,  1028 => 586,  1026 => 585,  1024 => 584,  1022 => 583,  1020 => 582,  1018 => 581,  1016 => 580,  1014 => 579,  1012 => 578,  1010 => 577,  1008 => 576,  1006 => 575,  1004 => 574,  1002 => 573,  1000 => 572,  998 => 571,  996 => 570,  994 => 569,  992 => 568,  990 => 567,  988 => 566,  985 => 564,  983 => 563,  981 => 562,  979 => 561,  977 => 560,  975 => 559,  973 => 558,  971 => 557,  969 => 556,  967 => 555,  965 => 554,  963 => 553,  961 => 552,  958 => 550,  956 => 549,  954 => 548,  952 => 547,  950 => 546,  947 => 544,  945 => 543,  943 => 542,  941 => 541,  939 => 540,  937 => 539,  935 => 538,  932 => 536,  929 => 534,  927 => 533,  925 => 532,  923 => 531,  921 => 530,  918 => 528,  916 => 527,  914 => 526,  911 => 524,  909 => 523,  907 => 522,  905 => 521,  903 => 520,  901 => 519,  899 => 518,  897 => 517,  895 => 516,  893 => 515,  891 => 514,  889 => 513,  887 => 512,  885 => 511,  883 => 510,  881 => 509,  879 => 508,  877 => 507,  875 => 506,  873 => 505,  871 => 504,  869 => 503,  867 => 502,  865 => 501,  863 => 500,  861 => 499,  859 => 498,  856 => 496,  854 => 495,  852 => 494,  850 => 493,  848 => 492,  846 => 491,  844 => 490,  842 => 489,  840 => 488,  838 => 487,  835 => 485,  833 => 484,  831 => 483,  828 => 481,  825 => 479,  823 => 478,  821 => 477,  819 => 476,  816 => 474,  813 => 472,  811 => 471,  809 => 470,  807 => 469,  805 => 468,  803 => 467,  801 => 466,  799 => 465,  797 => 464,  795 => 463,  793 => 462,  791 => 461,  789 => 460,  787 => 459,  785 => 458,  782 => 456,  779 => 454,  776 => 452,  774 => 451,  772 => 450,  770 => 449,  768 => 448,  766 => 447,  764 => 446,  762 => 445,  760 => 444,  758 => 443,  756 => 442,  754 => 441,  752 => 440,  750 => 439,  748 => 438,  746 => 437,  744 => 436,  742 => 435,  740 => 434,  737 => 432,  735 => 431,  733 => 430,  731 => 429,  729 => 428,  727 => 427,  725 => 426,  723 => 425,  721 => 424,  719 => 423,  717 => 422,  715 => 421,  713 => 420,  711 => 419,  709 => 418,  707 => 417,  705 => 416,  703 => 415,  701 => 414,  699 => 413,  697 => 412,  695 => 411,  693 => 410,  691 => 409,  689 => 408,  687 => 407,  685 => 406,  683 => 405,  681 => 404,  679 => 403,  677 => 402,  674 => 400,  671 => 398,  668 => 396,  666 => 395,  663 => 393,  660 => 391,  658 => 390,  655 => 388,  653 => 387,  650 => 385,  648 => 384,  646 => 383,  644 => 382,  642 => 381,  640 => 380,  638 => 379,  636 => 378,  634 => 377,  632 => 376,  630 => 375,  628 => 374,  626 => 373,  624 => 372,  621 => 370,  619 => 369,  617 => 368,  615 => 367,  613 => 366,  611 => 365,  609 => 364,  607 => 363,  605 => 362,  603 => 361,  601 => 360,  599 => 359,  597 => 358,  595 => 357,  593 => 356,  591 => 355,  589 => 354,  587 => 353,  585 => 352,  583 => 351,  581 => 350,  579 => 349,  577 => 348,  575 => 347,  573 => 346,  571 => 345,  569 => 344,  567 => 343,  565 => 342,  563 => 341,  561 => 340,  559 => 339,  557 => 338,  555 => 337,  553 => 336,  551 => 335,  549 => 334,  547 => 333,  545 => 332,  542 => 330,  539 => 328,  536 => 326,  533 => 324,  530 => 322,  528 => 321,  526 => 320,  523 => 318,  521 => 317,  519 => 316,  517 => 315,  515 => 314,  512 => 312,  510 => 311,  508 => 310,  506 => 309,  504 => 308,  502 => 307,  500 => 306,  498 => 305,  496 => 304,  494 => 303,  492 => 302,  489 => 300,  486 => 298,  484 => 297,  482 => 296,  479 => 294,  477 => 293,  475 => 292,  473 => 291,  471 => 290,  469 => 289,  467 => 288,  465 => 287,  463 => 286,  461 => 285,  459 => 284,  457 => 283,  455 => 282,  453 => 281,  451 => 280,  449 => 279,  447 => 278,  445 => 277,  443 => 276,  441 => 275,  439 => 274,  437 => 273,  435 => 272,  432 => 270,  429 => 268,  427 => 267,  425 => 266,  423 => 265,  421 => 264,  418 => 262,  416 => 261,  414 => 260,  411 => 258,  409 => 257,  407 => 256,  405 => 255,  403 => 254,  401 => 253,  398 => 251,  396 => 250,  394 => 249,  392 => 248,  390 => 247,  388 => 246,  386 => 245,  384 => 244,  382 => 243,  380 => 242,  377 => 240,  375 => 239,  373 => 238,  370 => 236,  367 => 234,  365 => 233,  362 => 231,  360 => 230,  358 => 229,  356 => 228,  275 => 149,  271 => 148,  265 => 145,  261 => 144,  255 => 141,  251 => 140,  247 => 139,  243 => 138,  235 => 133,  231 => 132,  225 => 129,  216 => 123,  204 => 114,  198 => 111,  192 => 108,  186 => 105,  180 => 102,  174 => 99,  168 => 96,  162 => 93,  156 => 90,  150 => 87,  144 => 84,  138 => 81,  132 => 78,  124 => 73,  116 => 67,  107 => 63,  46 => 5,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- PAGE FOOTER -->
<div class=\"page-footer\">
\t<div class=\"row\">
\t\t<div class=\"col-xs-12 col-sm-6\">
\t\t\t<span class=\"txt-color-white\">Admin <span class=\"hidden-xs\"> - </span> © {{ \"now\"|date(\"Y\") }}</span>
\t\t</div>

\t\t<div class=\"col-xs-6 col-sm-6 text-right hidden-xs\">
\t\t\t<div class=\"txt-color-white inline-block\">
\t\t\t\t<i class=\"txt-color-blueLight hidden-mobile\">Last account activity <i class=\"fa fa-clock-o\"></i> <strong>52 mins ago &nbsp;</strong> </i>
\t\t\t\t<div class=\"btn-group dropup\">
\t\t\t\t\t<button class=\"btn btn-xs dropdown-toggle bg-color-blue txt-color-white\" data-toggle=\"dropdown\">
\t\t\t\t\t\t<i class=\"fa fa-link\"></i> <span class=\"caret\"></span>
\t\t\t\t\t</button>
\t\t\t\t\t<ul class=\"dropdown-menu pull-right text-left\">
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<p class=\"txt-color-darken font-sm no-margin\">Download Progress</p>
\t\t\t\t\t\t\t\t<div class=\"progress progress-micro no-margin\">
\t\t\t\t\t\t\t\t\t<div class=\"progress-bar progress-bar-success\" style=\"width: 50%;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<p class=\"txt-color-darken font-sm no-margin\">Server Load</p>
\t\t\t\t\t\t\t\t<div class=\"progress progress-micro no-margin\">
\t\t\t\t\t\t\t\t\t<div class=\"progress-bar progress-bar-success\" style=\"width: 20%;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<p class=\"txt-color-darken font-sm no-margin\">Memory Load <span class=\"text-danger\">*critical*</span></p>
\t\t\t\t\t\t\t\t<div class=\"progress progress-micro no-margin\">
\t\t\t\t\t\t\t\t\t<div class=\"progress-bar progress-bar-danger\" style=\"width: 70%;\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"divider\"></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<div class=\"padding-5\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-block btn-default\">refresh</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</li>
\t\t\t\t\t</ul>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
<!-- END PAGE FOOTER -->

<!-- SHORTCUT AREA : With large tiles (activated via clicking user name tag)
Note: These tiles are completely responsive,
you can add as many as you like
-->
<div id=\"shortcut\">
\t<ul class=\"leftUl\">
\t\t<li class=\"leftLi\">
            <div class=\"creditField\">{{ translator.getLang('Credit') }} : {{ credit }}{{ currency|raw }}</div>
\t\t</li>

\t\t{#<a href=\"#\" class=\"jarvismetro-tile big-cubes selected bg-color-pinkDark\"> <span class=\"iconbox\"> <i class=\"fa fa-user fa-4x\"></i> <span>My Profile </span> </span> </a>#}
\t\t</li>
\t</ul>
</div>
<!-- END SHORTCUT AREA -->
<!-- MAIN APP JS FILE -->
<!-- PACE LOADER - turn this on if you want ajax loading to show (caution: uses lots of memory on iDevices)-->
<script data-pace-options='{ \"restartOnRequestAfter\": true }' src=\"{{ asset('js/plugin/pace/pace.min.js') }}\"></script>



<!-- IMPORTANT: APP CONFIG -->
<script src=\"{{ asset('js/app.config.js') }}\"></script>

<!-- JS TOUCH : include this plugin for mobile drag / drop touch events-->
<script src=\"{{ asset('js/plugin/jquery-touch/jquery.ui.touch-punch.min.js') }}\"></script>

<!-- BOOTSTRAP JS -->
<script src=\"{{ asset('js/bootstrap/bootstrap.min.js') }}\"></script>

<!-- CUSTOM NOTIFICATION -->
<script src=\"{{ asset('js/notification/SmartNotification.min.js') }}\"></script>

<!-- JARVIS WIDGETS -->
<script src=\"{{ asset('js/smartwidgets/jarvis.widget.min.js') }}\"></script>

<!-- EASY PIE CHARTS -->
<script src=\"{{ asset('js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js') }}\"></script>

<!-- SPARKLINES -->
<script src=\"{{ asset('js/plugin/sparkline/jquery.sparkline.min.js') }}\"></script>

<!-- JQUERY VALIDATE -->
<script src=\"{{ asset('js/plugin/jquery-validate/jquery.validate.min.js') }}\"></script>

<!-- JQUERY MASKED INPUT -->
<script src=\"{{ asset('js/plugin/masked-input/jquery.maskedinput.min.js') }}\"></script>

<!-- JQUERY SELECT2 INPUT -->
<script src=\"{{ asset('js/plugin/select2/select2.min.js') }}\"></script>

<!-- JQUERY UI + Bootstrap Slider -->
<script src=\"{{ asset('js/plugin/bootstrap-slider/bootstrap-slider.min.js') }}\"></script>

<!-- browser msie issue fix -->
<script src=\"{{ asset('js/plugin/msie-fix/jquery.mb.browser.min.js') }}\"></script>

<!-- FastClick: For mobile devices -->
<script src=\"{{ asset('js/plugin/fastclick/fastclick.min.js') }}\"></script>

<!--[if IE 8]>

<h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>

<![endif]-->

<!-- Demo purpose only -->
<script src=\"{{ asset('js/demo.min.js') }}\"></script>



<!-- ENHANCEMENT PLUGINS : NOT A REQUIREMENT -->
<!-- Voice command : plugin -->
<script src=\"{{ asset('js/speech/voicecommand.min.js') }}\"></script>

<!-- SmartChat UI : plugin -->
<script src=\"{{ asset('js/smart-chat-ui/smart.chat.ui.min.js') }}\"></script>
<script src=\"{{ asset('js/smart-chat-ui/smart.chat.manager.min.js') }}\"></script>

<!-- PAGE RELATED PLUGIN(S) -->

<!-- Flot Chart Plugin: Flot Engine, Flot Resizer, Flot Tooltip -->
<script src=\"{{ asset('js/plugin/flot/jquery.flot.cust.min.js') }}\"></script>
<script src=\"{{ asset('js/plugin/flot/jquery.flot.resize.min.js') }}\"></script>
<script src=\"{{ asset('js/plugin/flot/jquery.flot.time.min.js') }}\"></script>
<script src=\"{{ asset('js/plugin/flot/jquery.flot.tooltip.min.js') }}\"></script>

<!-- Vector Maps Plugin: Vectormap engine, Vectormap language -->
<script src=\"{{ asset('js/plugin/vectormap/jquery-jvectormap-1.2.2.min.js') }}\"></script>
<script src=\"{{ asset('js/plugin/vectormap/jquery-jvectormap-world-mill-en.js') }}\"></script>

<!-- Full Calendar -->
<script src=\"{{ asset('js/plugin/moment/moment.min.js') }}\"></script>
<script src=\"{{ asset('js/plugin/fullcalendar/jquery.fullcalendar.min.js') }}\"></script>
<script>
\t\$(document).ready(function(){
\t    \$('.top-menu-invisible li').on('click', function () {
\t\t\t\$('.top-menu-invisible li').removeClass('active')
\t\t\t\$(this).addClass('active')

\t\t\t\$('#subSectionName').text(\$(this).text())
        })
\t\t
\t\t\$('.sectionNm').on('click', function () {
\t\t\t\$('#sectionName').text(\$(this).text())
        })
\t})
</script>
<script>
    \$(document).ready(function() {

        // DO NOT REMOVE : GLOBAL FUNCTIONS!
        pageSetUp();

        /*
         * PAGE RELATED SCRIPTS
         */

        \$(\".js-status-update a\").click(function() {
            var selText = \$(this).text();
            var \$this = \$(this);
            \$this.parents('.btn-group').find('.dropdown-toggle').html(selText + ' <span class=\"caret\"></span>');
            \$this.parents('.dropdown-menu').find('li').removeClass('active');
            \$this.parent().addClass('active');
        });

        /*
        * TODO: add a way to add more todo's to list
        */

        // initialize sortable
        \$(function() {
            \$(\"#sortable1, #sortable2\").sortable({
                handle : '.handle',
                connectWith : \".todo\",
                update : countTasks
            }).disableSelection();
        });

        // check and uncheck
        \$('.todo .checkbox > input[type=\"checkbox\"]').click(function() {
            var \$this = \$(this).parent().parent().parent();

            if (\$(this).prop('checked')) {
                \$this.addClass(\"complete\");

                // remove this if you want to undo a check list once checked
                //\$(this).attr(\"disabled\", true);
                \$(this).parent().hide();

                // once clicked - add class, copy to memory then remove and add to sortable3
                \$this.slideUp(500, function() {
                    \$this.clone().prependTo(\"#sortable3\").effect(\"highlight\", {}, 800);
                    \$this.remove();
                    countTasks();
                });
            } else {
                // insert undo code here...
            }

        })
        // count tasks
        function countTasks() {

            \$('.todo-group-title').each(function() {
                var \$this = \$(this);
                \$this.find(\".num-of-tasks\").text(\$this.next().find(\"li\").size());
            });

        }

        {#{% if loggedUser != '' %}#}
        {#/*#}
        {#* RUN PAGE GRAPHS#}
        {#*/#}

        {#/* TAB 1: UPDATING CHART */#}
        {#// For the demo we use generated data, but normally it would be coming from the server#}

        {#var data = [], totalPoints = 200, \$UpdatingChartColors = \$(\"#updating-chart\").css('color');#}

        {#function getRandomData() {#}
        {#if (data.length > 0)#}
        {#data = data.slice(1);#}

        {#// do a random walk#}
        {#while (data.length < totalPoints) {#}
        {#var prev = data.length > 0 ? data[data.length - 1] : 50;#}
        {#var y = prev + Math.random() * 10 - 5;#}
        {#if (y < 0)#}
        {#y = 0;#}
        {#if (y > 100)#}
        {#y = 100;#}
        {#data.push(y);#}
        {#}#}

        {#// zip the generated y values with the x values#}
        {#var res = [];#}
        {#for (var i = 0; i < data.length; ++i)#}
        {#res.push([i, data[i]])#}
        {#return res;#}
        {#}#}

        {#// setup control widget#}
        {#var updateInterval = 1500;#}
        {#\$(\"#updating-chart\").val(updateInterval).change(function() {#}

        {#var v = \$(this).val();#}
        {#if (v && !isNaN(+v)) {#}
        {#updateInterval = +v;#}
        {#\$(this).val(\"\" + updateInterval);#}
        {#}#}

        {#});#}

        {#// setup plot#}
        {#var options = {#}
        {#yaxis : {#}
        {#min : 0,#}
        {#max : 100#}
        {#},#}
        {#xaxis : {#}
        {#min : 0,#}
        {#max : 100#}
        {#},#}
        {#colors : [\$UpdatingChartColors],#}
        {#series : {#}
        {#lines : {#}
        {#lineWidth : 1,#}
        {#fill : true,#}
        {#fillColor : {#}
        {#colors : [{#}
        {#opacity : 0.4#}
        {#}, {#}
        {#opacity : 0#}
        {#}]#}
        {#},#}
        {#steps : false#}

        {#}#}
        {#}#}
        {#};#}

        {#var plot = \$.plot(\$(\"#updating-chart\"), [getRandomData()], options);#}

        {#/* live switch */#}
        {#\$('input[type=\"checkbox\"]#start_interval').click(function() {#}
        {#if (\$(this).prop('checked')) {#}
        {#\$on = true;#}
        {#updateInterval = 1500;#}
        {#update();#}
        {#} else {#}
        {#clearInterval(updateInterval);#}
        {#\$on = false;#}
        {#}#}
        {#});#}

        {#function update() {#}
        {#if (\$on == true) {#}
        {#plot.setData([getRandomData()]);#}
        {#plot.draw();#}
        {#setTimeout(update, updateInterval);#}

        {#} else {#}
        {#clearInterval(updateInterval)#}
        {#}#}

        {#}#}

        {#var \$on = false;#}

        {#/*end updating chart*/#}

        {#/* TAB 2: Social Network  */#}

        {#\$(function() {#}
        {#// jQuery Flot Chart#}
        {#var twitter = [[1, 27], [2, 34], [3, 51], [4, 48], [5, 55], [6, 65], [7, 61], [8, 70], [9, 65], [10, 75], [11, 57], [12, 59], [13, 62]], facebook = [[1, 25], [2, 31], [3, 45], [4, 37], [5, 38], [6, 40], [7, 47], [8, 55], [9, 43], [10, 50], [11, 47], [12, 39], [13, 47]], data = [{#}
        {#label : \"Twitter\",#}
        {#data : twitter,#}
        {#lines : {#}
        {#show : true,#}
        {#lineWidth : 1,#}
        {#fill : true,#}
        {#fillColor : {#}
        {#colors : [{#}
        {#opacity : 0.1#}
        {#}, {#}
        {#opacity : 0.13#}
        {#}]#}
        {#}#}
        {#},#}
        {#points : {#}
        {#show : true#}
        {#}#}
        {#}, {#}
        {#label : \"Facebook\",#}
        {#data : facebook,#}
        {#lines : {#}
        {#show : true,#}
        {#lineWidth : 1,#}
        {#fill : true,#}
        {#fillColor : {#}
        {#colors : [{#}
        {#opacity : 0.1#}
        {#}, {#}
        {#opacity : 0.13#}
        {#}]#}
        {#}#}
        {#},#}
        {#points : {#}
        {#show : true#}
        {#}#}
        {#}];#}

        {#var options = {#}
        {#grid : {#}
        {#hoverable : true#}
        {#},#}
        {#colors : [\"#568A89\", \"#3276B1\"],#}
        {#tooltip : true,#}
        {#tooltipOpts : {#}
        {#//content : \"Value <b>\$x</b> Value <span>\$y</span>\",#}
        {#defaultTheme : false#}
        {#},#}
        {#xaxis : {#}
        {#ticks : [[1, \"JAN\"], [2, \"FEB\"], [3, \"MAR\"], [4, \"APR\"], [5, \"MAY\"], [6, \"JUN\"], [7, \"JUL\"], [8, \"AUG\"], [9, \"SEP\"], [10, \"OCT\"], [11, \"NOV\"], [12, \"DEC\"], [13, \"JAN+1\"]]#}
        {#},#}
        {#yaxes : {#}

        {#}#}
        {#};#}

        {#var plot3 = \$.plot(\$(\"#statsChart\"), data, options);#}
        {#});#}

        {#// END TAB 2#}

        {#// TAB THREE GRAPH //#}
        {#/* TAB 3: Revenew  */#}

        {#\$(function() {#}

        {#var trgt = [[1354586000000, 153], [1364587000000, 658], [1374588000000, 198], [1384589000000, 663], [1394590000000, 801], [1404591000000, 1080], [1414592000000, 353], [1424593000000, 749], [1434594000000, 523], [1444595000000, 258], [1454596000000, 688], [1464597000000, 364]], prft = [[1354586000000, 53], [1364587000000, 65], [1374588000000, 98], [1384589000000, 83], [1394590000000, 980], [1404591000000, 808], [1414592000000, 720], [1424593000000, 674], [1434594000000, 23], [1444595000000, 79], [1454596000000, 88], [1464597000000, 36]], sgnups = [[1354586000000, 647], [1364587000000, 435], [1374588000000, 784], [1384589000000, 346], [1394590000000, 487], [1404591000000, 463], [1414592000000, 479], [1424593000000, 236], [1434594000000, 843], [1444595000000, 657], [1454596000000, 241], [1464597000000, 341]], toggles = \$(\"#rev-toggles\"), target = \$(\"#flotcontainer\");#}

        {#var data = [{#}
        {#label : \"Target Profit\",#}
        {#data : trgt,#}
        {#bars : {#}
        {#show : true,#}
        {#align : \"center\",#}
        {#barWidth : 30 * 30 * 60 * 1000 * 80#}
        {#}#}
        {#}, {#}
        {#label : \"Actual Profit\",#}
        {#data : prft,#}
        {#color : '#3276B1',#}
        {#lines : {#}
        {#show : true,#}
        {#lineWidth : 3#}
        {#},#}
        {#points : {#}
        {#show : true#}
        {#}#}
        {#}, {#}
        {#label : \"Actual Signups\",#}
        {#data : sgnups,#}
        {#color : '#71843F',#}
        {#lines : {#}
        {#show : true,#}
        {#lineWidth : 1#}
        {#},#}
        {#points : {#}
        {#show : true#}
        {#}#}
        {#}]#}

        {#var options = {#}
        {#grid : {#}
        {#hoverable : true#}
        {#},#}
        {#tooltip : true,#}
        {#tooltipOpts : {#}
        {#//content: '%x - %y',#}
        {#//dateFormat: '%b %y',#}
        {#defaultTheme : false#}
        {#},#}
        {#xaxis : {#}
        {#mode : \"time\"#}
        {#},#}
        {#yaxes : {#}
        {#tickFormatter : function(val, axis) {#}
        {#return \"\$\" + val;#}
        {#},#}
        {#max : 1200#}
        {#}#}

        {#};#}

        {#plot2 = null;#}

        {#function plotNow() {#}
        {#var d = [];#}
        {#toggles.find(':checkbox').each(function() {#}
        {#if (\$(this).is(':checked')) {#}
        {#d.push(data[\$(this).attr(\"name\").substr(4, 1)]);#}
        {#}#}
        {#});#}
        {#if (d.length > 0) {#}
        {#if (plot2) {#}
        {#plot2.setData(d);#}
        {#plot2.draw();#}
        {#} else {#}
        {#plot2 = \$.plot(target, d, options);#}
        {#}#}
        {#}#}

        {#};#}

        {#toggles.find(':checkbox').on('change', function() {#}
        {#plotNow();#}
        {#});#}
        {#plotNow()#}

        {#});#}

        {#/*#}
        {#* VECTOR MAP#}
        {#*/#}

        {#data_array = {#}
        {#\"US\" : 4977,#}
        {#\"AU\" : 4873,#}
        {#\"IN\" : 3671,#}
        {#\"BR\" : 2476,#}
        {#\"TR\" : 1476,#}
        {#\"CN\" : 146,#}
        {#\"CA\" : 134,#}
        {#\"BD\" : 100#}
        {#};#}

        {#\$('#vector-map').vectorMap({#}
        {#map : 'world_mill_en',#}
        {#backgroundColor : '#fff',#}
        {#regionStyle : {#}
        {#initial : {#}
        {#fill : '#c4c4c4'#}
        {#},#}
        {#hover : {#}
        {#\"fill-opacity\" : 1#}
        {#}#}
        {#},#}
        {#series : {#}
        {#regions : [{#}
        {#values : data_array,#}
        {#scale : ['#85a8b6', '#4d7686'],#}
        {#normalizeFunction : 'polynomial'#}
        {#}]#}
        {#},#}
        {#onRegionLabelShow : function(e, el, code) {#}
        {#if ( typeof data_array[code] == 'undefined') {#}
        {#e.preventDefault();#}
        {#} else {#}
        {#var countrylbl = data_array[code];#}
        {#el.html(el.html() + ': ' + countrylbl + ' visits');#}
        {#}#}
        {#}#}
        {#});#}

        {#/*#}
        {#* FULL CALENDAR JS#}
        {#*/#}

        {#if (\$(\"#calendar\").length) {#}
        {#var date = new Date();#}
        {#var d = date.getDate();#}
        {#var m = date.getMonth();#}
        {#var y = date.getFullYear();#}

        {#var calendar = \$('#calendar').fullCalendar({#}

        {#editable : true,#}
        {#draggable : true,#}
        {#selectable : false,#}
        {#selectHelper : true,#}
        {#unselectAuto : false,#}
        {#disableResizing : false,#}
        {#height: \"auto\",#}

        {#header : {#}
        {#left : 'title', //,today#}
        {#center : 'prev, next, today',#}
        {#right : 'month, agendaWeek, agenDay' //month, agendaDay,#}
        {#},#}

        {#select : function(start, end, allDay) {#}
        {#var title = prompt('Event Title:');#}
        {#if (title) {#}
        {#calendar.fullCalendar('renderEvent', {#}
        {#title : title,#}
        {#start : start,#}
        {#end : end,#}
        {#allDay : allDay#}
        {#}, true // make the event \"stick\"#}
        {#);#}
        {#}#}
        {#calendar.fullCalendar('unselect');#}
        {#},#}

        {#events : [{#}
        {#title : 'All Day Event',#}
        {#start : new Date(y, m, 1),#}
        {#description : 'long description',#}
        {#className : [\"event\", \"bg-color-greenLight\"],#}
        {#icon : 'fa-check'#}
        {#}, {#}
        {#title : 'Long Event',#}
        {#start : new Date(y, m, d - 5),#}
        {#end : new Date(y, m, d - 2),#}
        {#className : [\"event\", \"bg-color-red\"],#}
        {#icon : 'fa-lock'#}
        {#}, {#}
        {#id : 999,#}
        {#title : 'Repeating Event',#}
        {#start : new Date(y, m, d - 3, 16, 0),#}
        {#allDay : false,#}
        {#className : [\"event\", \"bg-color-blue\"],#}
        {#icon : 'fa-clock-o'#}
        {#}, {#}
        {#id : 999,#}
        {#title : 'Repeating Event',#}
        {#start : new Date(y, m, d + 4, 16, 0),#}
        {#allDay : false,#}
        {#className : [\"event\", \"bg-color-blue\"],#}
        {#icon : 'fa-clock-o'#}
        {#}, {#}
        {#title : 'Meeting',#}
        {#start : new Date(y, m, d, 10, 30),#}
        {#allDay : false,#}
        {#className : [\"event\", \"bg-color-darken\"]#}
        {#}, {#}
        {#title : 'Lunch',#}
        {#start : new Date(y, m, d, 12, 0),#}
        {#end : new Date(y, m, d, 14, 0),#}
        {#allDay : false,#}
        {#className : [\"event\", \"bg-color-darken\"]#}
        {#}, {#}
        {#title : 'Birthday Party',#}
        {#start : new Date(y, m, d + 1, 19, 0),#}
        {#end : new Date(y, m, d + 1, 22, 30),#}
        {#allDay : false,#}
        {#className : [\"event\", \"bg-color-darken\"]#}
        {#}, {#}
        {#title : 'Smartadmin Open Day',#}
        {#start : new Date(y, m, 28),#}
        {#end : new Date(y, m, 29),#}
        {#className : [\"event\", \"bg-color-darken\"]#}
        {#}],#}


        {#eventRender : function(event, element, icon) {#}
        {#if (!event.description == \"\") {#}
        {#element.find('.fc-title').append(\"<br/><span class='ultra-light'>\" + event.description + \"</span>\");#}
        {#}#}
        {#if (!event.icon == \"\") {#}
        {#element.find('.fc-title').append(\"<i class='air air-top-right fa \" + event.icon + \" '></i>\");#}
        {#}#}
        {#}#}
        {#});#}

        {#};#}

        {#/* hide default buttons */#}
        {#\$('.fc-toolbar .fc-right, .fc-toolbar .fc-center').hide();#}

        {#// calendar prev#}
        {#\$('#calendar-buttons #btn-prev').click(function() {#}
        {#\$('.fc-prev-button').click();#}
        {#return false;#}
        {#});#}

        {#// calendar next#}
        {#\$('#calendar-buttons #btn-next').click(function() {#}
        {#\$('.fc-next-button').click();#}
        {#return false;#}
        {#});#}

        {#// calendar today#}
        {#\$('#calendar-buttons #btn-today').click(function() {#}
        {#\$('.fc-button-today').click();#}
        {#return false;#}
        {#});#}

        {#// calendar month#}
        {#\$('#mt').click(function() {#}
        {#\$('#calendar').fullCalendar('changeView', 'month');#}
        {#});#}

        {#// calendar agenda week#}
        {#\$('#ag').click(function() {#}
        {#\$('#calendar').fullCalendar('changeView', 'agendaWeek');#}
        {#});#}

        {#// calendar agenda day#}
        {#\$('#td').click(function() {#}
        {#\$('#calendar').fullCalendar('changeView', 'agendaDay');#}
        {#});#}

        {#/*#}
        {#* CHAT#}
        {#*/#}

        {#\$.filter_input = \$('#filter-chat-list');#}
        {#\$.chat_users_container = \$('#chat-container > .chat-list-body')#}
        {#\$.chat_users = \$('#chat-users')#}
        {#\$.chat_list_btn = \$('#chat-container > .chat-list-open-close');#}
        {#\$.chat_body = \$('#chat-body');#}

        {#/*#}
        {#* LIST FILTER (CHAT)#}
        {#*/#}

        {#// custom css expression for a case-insensitive contains()#}
        {#jQuery.expr[':'].Contains = function(a, i, m) {#}
        {#return (a.textContent || a.innerText || \"\").toUpperCase().indexOf(m[3].toUpperCase()) >= 0;#}
        {#};#}

        {#function listFilter(list) {// header is any element, list is an unordered list#}
        {#// create and add the filter form to the header#}

        {#\$.filter_input.change(function() {#}
        {#var filter = \$(this).val();#}
        {#if (filter) {#}
        {#// this finds all links in a list that contain the input,#}
        {#// and hide the ones not containing the input while showing the ones that do#}
        {#\$.chat_users.find(\"a:not(:Contains(\" + filter + \"))\").parent().slideUp();#}
        {#\$.chat_users.find(\"a:Contains(\" + filter + \")\").parent().slideDown();#}
        {#} else {#}
        {#\$.chat_users.find(\"li\").slideDown();#}
        {#}#}
        {#return false;#}
        {#}).keyup(function() {#}
        {#// fire the above change event after every letter#}
        {#\$(this).change();#}

        {#});#}

        {#}#}

        {#// on dom ready#}
        {#listFilter(\$.chat_users);#}

        {#// open chat list#}
        {#\$.chat_list_btn.click(function() {#}
        {#\$(this).parent('#chat-container').toggleClass('open');#}
        {#})#}

        {#\$.chat_body.animate({#}
        {#scrollTop : \$.chat_body[0].scrollHeight#}
        {#}, 500);#}
        {#{% endif %}#}

    });

</script>

<!-- Your GOOGLE ANALYTICS CODE Below -->
<script type=\"text/javascript\">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
    _gaq.push(['_trackPageview']);

    (function() {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();

</script>

<!-- IMPORTANT: APP CONFIG -->
<script src=\"{{ asset('js/app.config.js') }}\"></script>
<!-- CUSTOM NOTIFICATION -->
<script src=\"{{ asset('js/notification/SmartNotification.min.js') }}\"></script>

<!-- JARVIS WIDGETS -->
<script src=\"{{ asset('js/smartwidgets/jarvis.widget.min.js') }}\"></script>
<script src=\"{{ asset('js/app.min.js') }}\"></script>


", "default/base_structure/footer.html.twig", "/srv/workspace/backofficenew/templates/default/base_structure/footer.html.twig");
    }
}
